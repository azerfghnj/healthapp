package com.example.asclepius.data

import com.google.firebase.Timestamp
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import android.util.Log

data class VitalReading(
    val heartRate: Float?,
    val spo2: Float?,
    val temperature: Float?,
    val fall: Boolean,
    val systolic: Float? = null,
    val diastolic: Float? = null,
    val timestamp: Long = System.currentTimeMillis()
)

class DataUploader(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    private val TAG = "DataUploader"

    /**
     * Uploads reading for userId.
     * Returns true if the upload completed successfully, false otherwise.
     * Caller should call from coroutine (suspend).
     */
    suspend fun upload(userId: String, reading: VitalReading): Boolean {
        return try {
            val payload = hashMapOf<String, Any?>(
                "heartRate" to reading.heartRate,
                "spo2" to reading.spo2,
                "temperature" to reading.temperature,
                "fall" to reading.fall,
                "systolic" to reading.systolic,
                "diastolic" to reading.diastolic,
                // Use Firestore server timestamp for canonical time
                "serverTimestamp" to FieldValue.serverTimestamp(),
                // Optionally keep device timestamp for traceability
                "deviceTimestamp" to reading.timestamp
            )

            db.collection("users")
                .document(userId)
                .collection("readings")
                .add(payload)
                .await()

            true
        } catch (ex: Exception) {
            Log.w(TAG, "upload failed: ${ex.message}", ex)
            false
        }
    }
}
