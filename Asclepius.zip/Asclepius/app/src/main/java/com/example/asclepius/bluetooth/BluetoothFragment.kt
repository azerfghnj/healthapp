package com.example.asclepius.bluetooth

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.os.Bundle
import android.os.IBinder
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import com.example.asclepius.databinding.FragmentBluetoothBinding

class BluetoothFragment : Fragment() {

    private var _binding: FragmentBluetoothBinding? = null
    private val binding get() = _binding!!

    private var service: BluetoothService.LocalBinder? = null
    private var bound = false

    private val conn = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            // The service returns the LocalBinder (which extends Binder)
            service = binder as? BluetoothService.LocalBinder
            bound = true
            updateUi()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            bound = false
            service = null
            updateUi()
        }
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentBluetoothBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onStart() {
        super.onStart()
        // Bind to the service (will start if already running)
        requireContext().bindService(Intent(requireContext(), BluetoothService::class.java), conn, Context.BIND_AUTO_CREATE)
    }

    override fun onStop() {
        super.onStop()
        try {
            requireContext().unbindService(conn)
        } catch (_: Exception) { /* ignore if not bound */ }
        bound = false
    }

    private fun updateUi() {
        binding.statusText.text = if (bound && service?.isConnected() == true) "Connected to HC-06" else "Connecting…"
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
