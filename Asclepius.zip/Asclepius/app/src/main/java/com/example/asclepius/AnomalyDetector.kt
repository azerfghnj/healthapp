     package com.example.asclepius

     import android.app.NotificationChannel
     import android.app.NotificationManager
     import android.content.Context
     import android.os.Build
     import androidx.core.app.NotificationCompat
     import androidx.core.app.NotificationManagerCompat

     class AnomalyDetector(private val context: Context) {

         init {
             createNotificationChannel()
         }

         fun detectAnomaly(heartRate: Float, spo2: Float, temperature: Float, parameters: UserParameters): Boolean {
             val isAnomaly = when {
                 heartRate < 60 || heartRate > 100 -> true
                 spo2 < 95 -> true
                 temperature < 36 || temperature > 38 -> true
                 else -> false
             }

             if (isAnomaly) {
                 sendNotification("Health Anomaly Detected", "Check your health readings: HR=$heartRate, SpO2=$spo2, Temp=$temperature")
             }
             return isAnomaly
         }

         private fun createNotificationChannel() {
             if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                 val name = "Health Alerts"
                 val descriptionText = "Notifications for health anomalies"
                 val importance = NotificationManager.IMPORTANCE_HIGH
                 val channel = NotificationChannel("HEALTH_CHANNEL", name, importance).apply {
                     description = descriptionText
                 }
                 val notificationManager: NotificationManager =
                     context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                 notificationManager.createNotificationChannel(channel)
             }
         }

         private fun sendNotification(title: String, message: String) {
             val builder = NotificationCompat.Builder(context, "HEALTH_CHANNEL")
                 .setSmallIcon(R.drawable.ic_notification)
                 .setContentTitle(title)
                 .setContentText(message)
                 .setPriority(NotificationCompat.PRIORITY_HIGH)
                 .setAutoCancel(true)

             with(NotificationManagerCompat.from(context)) {
                 notify(System.currentTimeMillis().toInt(), builder.build())
             }
         }
     }

     data class UserParameters(
         val age: Int,
         val gender: String,
         val height: Float,
         val weight: Float,
         val conditions: Set<String>
     )
