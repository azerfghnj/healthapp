package com.example.asclepius.bluetooth

import android.util.Log

data class ParsedReading(
    val spo2: Float?,
    val hr: Float?,
    val temp: Float?,
    val fall: Boolean,
    val systolic: Float? = null,
    val diastolic: Float? = null
)

fun parseLine(line: String): ParsedReading? {
    Log.d("Parsing", "Raw input line: $line")

    // Case-insensitive regex with flexible whitespace and optional units
    val spo2 = Regex("""(?i)SpO2\s*:\s*([0-9]+(?:\.[0-9]+)?)\s*%?""").find(line)?.groupValues?.get(1)?.toFloatOrNull()
    val hr   = Regex("""(?i)HR\s*:\s*([0-9]+(?:\.[0-9]+)?)\s*bpm?""").find(line)?.groupValues?.get(1)?.toFloatOrNull()
    val temp = Regex("""(?i)(Temp|Temperature)\s*:\s*([0-9]+(?:\.[0-9]+)?)\s*(?:°C|C)?""").find(line)?.groupValues?.get(2)?.toFloatOrNull()

    // Fall detection: handle "Fall: No Fall" or "Fall: Fall Detected"
    val fallText = Regex("""(?i)Fall\s*:\s*(.+)""").find(line)?.groupValues?.get(1)
    val fall = fallText?.contains("No", ignoreCase = true)?.not() ?: false

    // Blood pressure: handle "SYS=120.0 DIA=80.0" or "BP: 120/80"
    val bpMatch = Regex("""(?i)(?:SYS\s*=\s*|BP\s*:\s*)([0-9]+(?:\.[0-9]+)?)(?:\s*DIA\s*=\s*|/)([0-9]+(?:\.[0-9]+)?)""").find(line)
    val sys = bpMatch?.groupValues?.get(1)?.toFloatOrNull()
    val dia = bpMatch?.groupValues?.get(2)?.toFloatOrNull()

    // Log parsed values for debugging
    Log.d("Parsing", "Parsed - SpO2: $spo2, HR: $hr, Temp: $temp, Fall: $fall, Sys: $sys, Dia: $dia")

    // Return null if no meaningful values are parsed
    if (spo2 == null && hr == null && temp == null && sys == null && dia == null && fallText == null) {
        return null
    }

    return ParsedReading(spo2 = spo2, hr = hr, temp = temp, fall = fall, systolic = sys, diastolic = dia)
}