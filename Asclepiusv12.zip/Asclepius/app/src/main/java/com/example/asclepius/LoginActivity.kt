package com.example.asclepius

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase

class LoginActivity : AppCompatActivity() {

    private val auth by lazy { FirebaseAuth.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val emailInput = findViewById<EditText>(R.id.emailInput)
        val passInput = findViewById<EditText>(R.id.passInput)
        val loginBtn = findViewById<Button>(R.id.loginBtn)
        val goSignupBtn = findViewById<Button>(R.id.goSignupBtn)
        val progress = findViewById<ProgressBar>(R.id.progressBar)

        goSignupBtn.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
        loginBtn.setOnClickListener {
            val email = emailInput.text.toString().trim()
            val pass = passInput.text.toString().trim()


            if (email.isEmpty() || pass.length < 6) {
                Toast.makeText(this, "Enter a valid email and password (>=6 chars)", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            loginBtn.isEnabled = false
            progress.visibility = View.VISIBLE

            signInOrCreate(email, pass, loginBtn, progress)
        }
    }

    private fun signInOrCreate(
        email: String,
        pass: String,
        loginBtn: Button,
        progress: ProgressBar
    ) {
        auth.signInWithEmailAndPassword(email, pass)
            .addOnSuccessListener {
                val user = auth.currentUser
                if (user != null && user.isEmailVerified) {
                    startMain()
                } else {
                    user?.sendEmailVerification()
                    Toast.makeText(this, "Please verify your email. Verification link sent again.", Toast.LENGTH_LONG).show()
                    auth.signOut()
                    loginBtn.isEnabled = true
                    progress.visibility = View.GONE
                }
            }
            .addOnFailureListener {
                // Try to create new account
                auth.createUserWithEmailAndPassword(email, pass)
                    .addOnSuccessListener { result ->
                        val uid = result.user?.uid ?: return@addOnSuccessListener

                        // Save basic profile to DB
                        val db = FirebaseDatabase.getInstance().getReference("patients/$uid")
                        val profile = mapOf(
                            "email" to email,
                            "createdAt" to System.currentTimeMillis()
                        )
                        db.setValue(profile)

                        // Send verification email
                        result.user?.sendEmailVerification()
                        Toast.makeText(this, "Account created! Please check email to verify.", Toast.LENGTH_LONG).show()

                        auth.signOut()
                        loginBtn.isEnabled = true
                        progress.visibility = View.GONE
                    }
                    .addOnFailureListener { ex ->
                        Toast.makeText(this, "Auth failed: ${ex.message}", Toast.LENGTH_LONG).show()
                        loginBtn.isEnabled = true
                        progress.visibility = View.GONE
                    }
            }
    }

    private fun startMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
