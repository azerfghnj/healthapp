package com.example.asclepius

data class ChatMessage(
    val message: String,
    val isSentByUser: Boolean // True for user messages, false for bot responses
)