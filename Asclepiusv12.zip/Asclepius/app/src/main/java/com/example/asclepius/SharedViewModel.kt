package com.example.asclepius

import android.net.Uri
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class SharedViewModel : ViewModel() {
    private val _profileImage = MutableLiveData<Uri?>()
    val profileImage: LiveData<Uri?> = _profileImage

    fun setProfileImage(uri: Uri?) {
        _profileImage.value = uri
    }
}
