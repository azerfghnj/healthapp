package com.example.asclepius

import android.app.*
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*

class SensorService : Service() {

    private val coroutineScope = CoroutineScope(Dispatchers.IO + Job())

    override fun onCreate() {
        super.onCreate()
        startForegroundServiceNotification()
        startCollectingData()
    }

    private fun startForegroundServiceNotification() {
        val channelId = "SENSOR_SERVICE_CHANNEL"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Sensor Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("HealthGuard Sensor Active")
            .setContentText("Collecting sensor data")
            .setSmallIcon(R.drawable.ic_notification)
            .build()

        startForeground(1, notification)
    }

    private fun startCollectingData() {
        coroutineScope.launch {
            while (isActive) {
                val heartRate = readHeartRate()
                val spo2 = readSpO2()
                val temperature = readTemperature()
                val fallDetected = detectFall()
                val systolic = readSystolic()
                val diastolic = readDiastolic()

                // Broadcast to UI (make sure ChartsFragment listens to this action)
                val intent = Intent("com.example.asclepius.SENSOR_UPDATE")
                intent.putExtra("heartRate", heartRate)
                intent.putExtra("spo2", spo2)
                intent.putExtra("temperature", temperature)
                intent.putExtra("fallDetected", fallDetected)
                intent.putExtra("systolic", systolic)
                intent.putExtra("diastolic", diastolic)
                sendBroadcast(intent)

                delay(1000) // update every second
            }
        }
    }

    // simple random simulators (replace with real sensor reads)
    private fun readHeartRate(): Float = (60..100).random().toFloat()
    private fun readSpO2(): Float = (95..100).random().toFloat()
    private fun readTemperature(): Float = (36..38).random().toFloat()
    private fun detectFall(): Boolean = false
    private fun readSystolic(): Float = (110..130).random().toFloat()
    private fun readDiastolic(): Float = (70..85).random().toFloat()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        coroutineScope.cancel()
    }
}
