package com.example.asclepius.bluetooth

data class ParsedReading(val spo2: Float, val hr: Float, val temp: Float, val fall: Boolean)

fun parseLine(line: String): ParsedReading? {
    val spo2 = Regex("""SpO2:\s*([0-9]+(?:\.[0-9]+)?)""").find(line)?.groupValues?.get(1)?.toFloatOrNull()
    val hr   = Regex("""HR:\s*([0-9]+(?:\.[0-9]+)?)""").find(line)?.groupValues?.get(1)?.toFloatOrNull()
    val temp = Regex("""Temp:\s*([0-9]+(?:\.[0-9]+)?)""").find(line)?.groupValues?.get(1)?.toFloatOrNull()
    val fall = Regex("""Fall:\s*(.+)""").find(line)?.groupValues?.get(1)?.contains("No", ignoreCase = true)?.not() ?: false
    return if (spo2 != null && hr != null && temp != null) ParsedReading(spo2, hr, temp, fall) else null
}
