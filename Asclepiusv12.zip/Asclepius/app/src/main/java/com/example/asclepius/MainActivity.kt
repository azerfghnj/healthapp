package com.example.asclepius

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import com.example.asclepius.bluetooth.BluetoothPermissionHelper
import com.example.asclepius.bluetooth.BluetoothService
import com.example.asclepius.databinding.ActivityMainBinding
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener, OnProfileImageUpdatedListener {

    private lateinit var binding: ActivityMainBinding
    private lateinit var predictionRef: DatabaseReference
    private val useFakeBluetooth = false // true = simulate, false = real HC-06

    override fun onProfileImageUpdated(uri: Uri?) {
        updateHeaderImage(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val current = FirebaseAuth.getInstance().currentUser
        if (current == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        setupPredictionListener(current.uid)
        setupDrawerAndHeader()

        // Handle back button for drawer
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    binding.drawerLayout.closeDrawer(GravityCompat.START)
                } else finish()
            }
        })

        // Default fragment
        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
            binding.navView.setCheckedItem(R.id.nav_home)
        }

       // ensureBluetoothReady()
    }

    // ------------------ HEADER IMAGE SYNC ------------------
    private fun setupDrawerAndHeader() {
        val header = binding.navView.getHeaderView(0)
        val ivAvatar = header.findViewById<ImageView>(R.id.ivHeaderAvatar)
        val tvUsername = header.findViewById<TextView>(R.id.tvHeaderName)

        val prefs = getSharedPreferences("UserProfile", MODE_PRIVATE)
        val name = prefs.getString("name", "Asclepius")
        val imgUri = prefs.getString("profileImage", null)

        tvUsername.text = name
        updateHeaderImage(if (imgUri != null) Uri.parse(imgUri) else null)

        // 🔒 Prevent changing the image from MainActivity
        ivAvatar.isClickable = false
        ivAvatar.isFocusable = false

        val toggle = ActionBarDrawerToggle(
            this, binding.drawerLayout,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
        binding.navView.setNavigationItemSelectedListener(this)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeButtonEnabled(true)
    }

    private fun updateHeaderImage(uri: Uri?) {
        val header = binding.navView.getHeaderView(0)
        val ivAvatar = header.findViewById<ImageView>(R.id.ivHeaderAvatar)
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
                ivAvatar.setImageURI(uri)
            } catch (e: SecurityException) {
                Log.e("MainActivity", "Permission denied for image URI: ${e.message}")
                ivAvatar.setImageResource(R.drawable.ic_avatar_placeholder)
            }
        } else {
            ivAvatar.setImageResource(R.drawable.ic_avatar_placeholder)
        }
    }

    override fun onResume() {
        super.onResume()
        // ✅ Always refresh header image when returning from ParametersFragment
        val prefs = getSharedPreferences("UserProfile", MODE_PRIVATE)
        val imgUri = prefs.getString("profileImage", null)
        updateHeaderImage(if (imgUri != null) Uri.parse(imgUri) else null)
    }

    // ------------------ FIREBASE PREDICTION LISTENER ------------------
    private fun setupPredictionListener(userId: String) {
        predictionRef = FirebaseDatabase.getInstance()
            .getReference("patients/$userId/prediction")

        predictionRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val riskCategory = snapshot.child("Risk Category").getValue(String::class.java)
                    val explanation = snapshot.child("Explanation").getValue(String::class.java)

                    (supportFragmentManager.findFragmentById(R.id.fragment_container) as? HomeFragment)
                        ?.updateRiskUI(riskCategory ?: "N/A", explanation ?: "No explanation")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("Firebase", "Prediction read failed: ${error.message}")
            }
        })
    }

    // ------------------ BLUETOOTH ------------------
    private val enableBtLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { startSensorService() }

    private fun ensureBluetoothReady() {
        if (!BluetoothPermissionHelper.hasAllPermissions(this)) {
            BluetoothPermissionHelper.requestPermissions(this, 1001)
        } else {
            BluetoothPermissionHelper.requestEnableBluetooth(enableBtLauncher)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001) {
            BluetoothPermissionHelper.requestEnableBluetooth(enableBtLauncher)
        }
    }

    private fun startSensorService() {
        val intent = if (useFakeBluetooth) {
            Intent(this, FakeBluetoothService::class.java)
        } else {
            Intent(this, BluetoothService::class.java)
        }
        startForegroundService(intent)
    }


    // ------------------ NAVIGATION CLICK HANDLER ------------------
    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_home -> loadFragment(HomeFragment())
            R.id.nav_charts -> loadFragment(ChartsFragment())
            R.id.nav_chatbot -> startActivity(Intent(this, ChatbotActivity::class.java))
            R.id.nav_parameters -> loadFragment(ParametersFragment())
        }
        binding.drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun logoutUser() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Logout")
            .setMessage("Are you sure you want to log out?")
            .setPositiveButton("Yes") { _, _ ->
                FirebaseAuth.getInstance().signOut()
                val prefs = getSharedPreferences("UserProfile", MODE_PRIVATE)
                prefs.edit().clear().apply()

                val intent = Intent(this, LoginActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                binding.drawerLayout.closeDrawer(GravityCompat.START)
            } else {
                binding.drawerLayout.openDrawer(GravityCompat.START)
            }
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
