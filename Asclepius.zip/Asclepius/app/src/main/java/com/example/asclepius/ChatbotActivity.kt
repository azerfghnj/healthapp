package com.example.asclepius

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.asclepius.databinding.ActivityChatbotBinding
import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.asclepius.ChatMessage

class ChatbotActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatbotBinding
    private val chatMessages = mutableListOf<ChatMessage>()
    private lateinit var chatAdapter: ChatAdapter
    private val TAG = "ChatbotActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatbotBinding.inflate(layoutInflater)
        setContentView(binding.root)

        chatAdapter = ChatAdapter(chatMessages)
        binding.rvChat.layoutManager = LinearLayoutManager(this).apply {
            stackFromEnd = true
        }
        binding.rvChat.adapter = chatAdapter

        chatAdapter.addMessage(ChatMessage("Hello! I'm your Health Assistant. How can I help you today?", false))
        chatAdapter.addMessage(ChatMessage("Note: Your conversations are processed by Google's AI to provide responses. " +
                "Please avoid sharing personally identifiable information.", false))

        binding.btnSend.setOnClickListener {
            Log.d(TAG, "Send button clicked.")
            sendMessage()
        }

        binding.ivBack.setOnClickListener {
            Log.d(TAG, "Back button clicked. Finishing activity.")
            onBackPressedDispatcher.onBackPressed()
        }

        binding.etMessage.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) {
                Log.d(TAG, "Enter key pressed (IME_ACTION_SEND).")
                sendMessage()
                true
            } else {
                false
            }
        }
    }

    private fun sendMessage() {
        val message = binding.etMessage.text.toString().trim()
        Log.d(TAG, "sendMessage called with message: '$message'")
        if (message.isNotEmpty()) {
            addUserMessage(message)
            binding.etMessage.text.clear()
            generateResponse(message)
        } else {
            Log.d(TAG, "Message is empty, not sending.")
        }
    }

    private fun addUserMessage(message: String) {
        chatMessages.add(ChatMessage(message, true))
        chatAdapter.notifyItemInserted(chatMessages.size - 1)
        binding.rvChat.smoothScrollToPosition(chatMessages.size - 1)
        Log.d(TAG, "User message added: '$message'")
    }

    private fun addBotMessage(message: String) {
        chatMessages.add(ChatMessage(message, false))
        chatAdapter.notifyItemInserted(chatMessages.size - 1)
        binding.rvChat.smoothScrollToPosition(chatMessages.size - 1)
        Log.d(TAG, "Bot message added: '$message'")
    }

    private fun generateResponse(userMessage: String) {
        Log.d(TAG, "generateResponse called for user message: '$userMessage'")

        chatMessages.add(ChatMessage("...", false))
        val loadingPosition = chatMessages.size - 1
        chatAdapter.notifyItemInserted(loadingPosition)
        binding.rvChat.smoothScrollToPosition(loadingPosition)
        Log.d(TAG, "Loading indicator added.")

        CoroutineScope(Dispatchers.IO).launch {
            Log.d(TAG, "CoroutineScope launched on Dispatchers.IO.")
            try {
                Log.d(TAG, "API Key: ${BuildConfig.GEMINI_API_KEY}")

                if (BuildConfig.GEMINI_API_KEY.isEmpty() || BuildConfig.GEMINI_API_KEY == "YOUR_API_KEY") {
                    withContext(Dispatchers.Main) {
                        chatMessages.removeAt(loadingPosition)
                        chatAdapter.notifyItemRemoved(loadingPosition)
                        addBotMessage("Error: API key is missing or invalid. Please check your secret.properties file and Google AI Studio.")
                    }
                    Log.e(TAG, "API Key is empty or default. Aborting API call.")
                    return@launch
                }

                val generativeModel = GenerativeModel(
                    modelName = "gemini-2.5-flash",
                    apiKey = BuildConfig.GEMINI_API_KEY
                )
                Log.d(TAG, "GenerativeModel initialized with model: gemini-2.5-flash")

                val sharedPref = getSharedPreferences("health_data", Context.MODE_PRIVATE)
                val age = sharedPref.getInt("age", 0)
                val gender = sharedPref.getString("gender", "Not specified")
                val conditions = sharedPref.getString("conditions", "None")
                Log.d(TAG, "SharedPreferences data loaded: Age=$age, Gender=$gender, Conditions=$conditions")

                val healthContext = """
                    You are a professional health assistant named "Health Monitor AI".
                    Provide helpful, accurate, and empathetic responses to health-related questions.

                    Important guidelines:
                    1. If asked about symptoms, remind users to consult a real doctor
                    2. Do not provide medical diagnoses - only offer general information
                    3. Be empathetic and understanding
                    4. For medication questions, advise consulting a pharmacist
                    5. Encourage healthy lifestyle choices
                    6. For emergencies, advise contacting local emergency services
                    7. Never suggest dangerous or unverified treatments

                    User's health parameters (if available):
                    - Age: $age
                    - Gender: $gender
                    - Conditions: $conditions

                    Conversation history:
                    ${chatMessages.joinToString("\n") {
                    "${if (it.isSentByUser) "User" else "Assistant"}: ${it.message}"
                }}

                    User's new message: $userMessage
                """.trimIndent()
                Log.d(TAG, "Health context prepared. Calling generateContent...")

                val response = generativeModel.generateContent(healthContext)
                val botResponse = response.text ?: "I couldn't process your request."
                Log.d(TAG, "Gemini response received: '$botResponse'")

                withContext(Dispatchers.Main) {
                    Log.d(TAG, "Updating UI on Main thread.")
                    chatMessages.removeAt(loadingPosition)
                    chatAdapter.notifyItemRemoved(loadingPosition)
                    addBotMessage(botResponse)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error during Gemini API call: ${e.message}", e)
                withContext(Dispatchers.Main) {
                    Log.d(TAG, "Handling error on Main thread.")
                    chatMessages.removeAt(loadingPosition)
                    chatAdapter.notifyItemRemoved(loadingPosition)

                    val errorMessage = when {
                        e.message?.contains("Unable to resolve host", ignoreCase = true) == true -> "Network error. Check your internet connection."
                        e.message?.contains("403", ignoreCase = true) == true -> "API key invalid or quota exceeded. Check Google Cloud Console."
                        e.message?.contains("404", ignoreCase = true) == true -> "Invalid API endpoint or model. Verify configuration."
                        e.message?.contains("500", ignoreCase = true) == true -> "Server error. Please try again later."
                        e.message?.contains("503", ignoreCase = true) == true -> "Service unavailable. Please try again later."
                        else -> "Error: ${e.message}. Please try again later."
                    }
                    addBotMessage(errorMessage)
                }
            }
        }
    }
}