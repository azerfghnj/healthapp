package com.example.asclepius.data

import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

data class VitalReading(
    val ts: Long = System.currentTimeMillis(),
    val heartRate: Float,
    val spo2: Float,
    val temperature: Float,
    val fall: Boolean
)

class DataUploader(
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    /**
     * Suspends until document is added or throws.
     * Caller should call from coroutine.
     */
    suspend fun upload(userId: String, reading: VitalReading) {
        db.collection("users")
            .document(userId)
            .collection("readings")
            .add(reading)
            .await()
    }
}
