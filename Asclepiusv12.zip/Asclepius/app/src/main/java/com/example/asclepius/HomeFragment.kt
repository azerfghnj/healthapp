package com.example.asclepius

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.asclepius.databinding.FragmentHomeBinding
import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.widget.TextView
import android.widget.Toast
import android.app.Activity
import com.example.asclepius.FakeBluetoothService

class HomeFragment : Fragment() {
    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    private val bluetoothReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d("HomeFragment", "Broadcast received: ${intent?.action}, extras: ${intent?.extras?.keySet()?.joinToString()}")

            if (intent?.action == "com.example.asclepius.BLUETOOTH_DATA") {
                val heartRate = intent.getIntExtra("heartRate", -1)
                val spo2 = intent.getIntExtra("spo2", -1)
                val temperature = intent.getFloatExtra("temperature", -1f)
                val systolic = intent.getFloatExtra("systolic", -1f)
                val diastolic = intent.getFloatExtra("diastolic", -1f)

                binding.tvHeartRate.text =
                    "Heart Rate: ${if (heartRate >= 0) "$heartRate bpm" else "-- bpm"}"

                binding.tvSpo2.text =
                    "SpO2: ${if (spo2 >= 0) "$spo2 %" else "-- %"}"

                binding.tvTemperature.text =
                    "Temperature: ${if (temperature >= 0f) "%.1f °C".format(temperature) else "-- °C"}"

                binding.tvBloodPressure.text =
                    if (systolic > 0 && diastolic > 0)
                        "Blood Pressure: ${Math.round(systolic)}/${Math.round(diastolic)} mmHg"
                    else
                        "Blood Pressure: --/-- mmHg"
            }
        }
    }

    private val requestBluetoothPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            checkAndEnableBluetooth()
        } else {
            Toast.makeText(requireContext(), "Bluetooth permission denied", Toast.LENGTH_SHORT).show()
        }
    }

    private val enableBluetoothLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result: ActivityResult ->
        if (result.resultCode == Activity.RESULT_OK) {
            startBluetoothService()
        } else {
            Toast.makeText(requireContext(), "Bluetooth activation cancelled", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Default placeholders
        binding.tvHeartRate.text = "Heart Rate: -- bpm"
        binding.tvSpo2.text = "SpO2: -- %"
        binding.tvTemperature.text = "Temperature: -- °C"
        binding.tvBloodPressure.text = "Blood Pressure: --/-- mmHg"

        // START SERVICE ONLY WHEN CLICKED
        binding.connectButton.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (ContextCompat.checkSelfPermission(
                        requireContext(),
                        Manifest.permission.BLUETOOTH_CONNECT
                    ) != android.content.pm.PackageManager.PERMISSION_GRANTED
                ) {
                    requestBluetoothPermissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
                } else {
                    checkAndEnableBluetooth()
                }
            } else {
                checkAndEnableBluetooth()
            }
        }
    }

    private fun checkAndEnableBluetooth() {
        val bluetoothAdapter = BluetoothAdapter.getDefaultAdapter()
        if (bluetoothAdapter == null) {
            Toast.makeText(requireContext(), "Device does not support Bluetooth", Toast.LENGTH_SHORT).show()
            return
        }
        if (!bluetoothAdapter.isEnabled) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            enableBluetoothLauncher.launch(enableBtIntent)
        } else {
            startBluetoothService()
        }
    }

    private fun startBluetoothService() {
        val intent = Intent(requireContext(), FakeBluetoothService::class.java)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            requireContext().startForegroundService(intent)
        else
            requireContext().startService(intent)
    }

    override fun onResume() {
        super.onResume()
        requireContext().registerReceiver(
            bluetoothReceiver,
            IntentFilter("com.example.asclepius.BLUETOOTH_DATA")
        )
    }

    override fun onPause() {
        super.onPause()
        requireContext().unregisterReceiver(bluetoothReceiver)
    }

    fun updateRiskUI(riskCategory: String, explanation: String) {
        view?.findViewById<TextView>(R.id.textRiskCategory)?.text = "Risk: $riskCategory"
        view?.findViewById<TextView>(R.id.textExplanation)?.text = explanation
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}