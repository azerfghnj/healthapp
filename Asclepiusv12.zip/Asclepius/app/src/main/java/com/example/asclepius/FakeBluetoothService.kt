package com.example.asclepius

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.*
import kotlin.random.Random
import kotlin.math.roundToInt

class FakeBluetoothService : Service() {

    private val scope = CoroutineScope(Dispatchers.IO + Job())
    private val TAG = "FakeBluetoothService"
    private val CHANNEL_ID = "FAKE_BT_CHANNEL"
    private val NOTIF_ID = 102
    // State variables to allow smooth changes over time
    private var hr = 75
    private var spo2 = 98f
    private var temp = 36.7f
    private var sys = 118f
    private var dia = 76f
    private var time = 0.0

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Scanning for device…"))

        // Simulate connection sequence
        scope.launch {
            delay(1000) // scanning
            updateNotification("Connecting to HC-06…")
            delay(1500) // connecting
            updateNotification("Connected to HC-06")

            // Start sending simulated data every second
            while (isActive) {
                sendFakeData()
                delay(1000)
            }
        }
    }

    private fun sendFakeData() {

        // Time for slow oscillations
        time += 0.2

        // ----- HEART RATE -----
        // Natural drift + small noise
        hr += Random.nextInt(-2, 3)
        hr = hr.coerceIn(65, 90) // healthy 25 y/o range

        // ----- SPO2 -----
        spo2 += Random.nextDouble(-0.3, 0.3).toFloat()
        spo2 = spo2.coerceIn(96f, 99.5f)

        // ----- TEMPERATURE -----
        // Slow sinusoidal change (breathing/circadian)
        val baseTemp = 36.6 + 0.15 * kotlin.math.sin(time)
        val noise = Random.nextDouble(-0.05, 0.05)
        temp = (baseTemp + noise).toFloat()
        temp = temp.coerceIn(36.4f, 37.0f)

        // ----- BLOOD PRESSURE -----
        // BP correlates slightly with HR
        val targetSys = 116 + (hr - 75) * 0.25
        val targetDia = 76 + (hr - 75) * 0.1

        sys += Random.nextDouble(-1.0, 1.2).toFloat()
        dia += Random.nextDouble(-0.5, 0.8).toFloat()

        sys = sys * 0.8f + targetSys.toFloat() * 0.2f
        dia = dia * 0.85f + targetDia.toFloat() * 0.15f

        sys = sys.coerceIn(108f, 125f)
        dia = dia.coerceIn(68f, 82f)

        // ----- FALL -----
        val fall = false // still no fall for healthy person


        // ----- SEND -----
        val intent = Intent("com.example.asclepius.BLUETOOTH_DATA").apply {
            putExtra("heartRate", hr)
            putExtra("spo2", spo2.toInt())
            putExtra("temperature", temp)
            putExtra("fall", fall)
            putExtra("systolic", sys)
            putExtra("diastolic", dia)
        }

        sendBroadcast(intent)

        Log.d(
            TAG,
            "Simulated realistic data: HR=$hr, SpO2=${spo2.toInt()}, Temp=${"%.2f".format(temp)}, BP=${sys.toInt()}/${dia.toInt()}"
        )
    }


    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Fake Bluetooth", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Asclepius Fake BT")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_ID, buildNotification(text))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
