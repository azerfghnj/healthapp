package com.example.asclepius

import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.example.asclepius.databinding.FragmentParametersBinding
import android.widget.Toast

class ParametersFragment : Fragment() {
    private var _binding: FragmentParametersBinding? = null
    private val binding get() = _binding!!
    private val conditionsList = mutableListOf<String>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentParametersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Load saved data
        loadSavedData()

        // Initialize Gender Spinner
        binding.spinnerGender.adapter = ArrayAdapter.createFromResource(
            requireContext(),
            R.array.gender_options,
            android.R.layout.simple_spinner_item
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        // Initialize Conditions Spinner
        conditionsList.addAll(resources.getStringArray(R.array.conditions_options).toMutableList())
        val adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, conditionsList)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerConditions.adapter = adapter

        // Add New Condition
        binding.btnAddCondition.setOnClickListener {
            val builder = AlertDialog.Builder(requireContext())
            builder.setTitle("Add New Condition")
            val input = EditText(requireContext())
            builder.setView(input)
            builder.setPositiveButton("Add") { _, _ ->
                val newCondition = input.text.toString().trim()
                if (newCondition.isNotEmpty() && !conditionsList.contains(newCondition)) {
                    conditionsList.add(newCondition)
                    adapter.notifyDataSetChanged()
                    Toast.makeText(context, "Condition added: $newCondition", Toast.LENGTH_SHORT).show()
                }
            }
            builder.setNegativeButton("Cancel") { dialog, _ -> dialog.cancel() }
            builder.show()
        }

        // Save Button
        binding.btnSave.setOnClickListener {
            saveData()
            Toast.makeText(context, "Parameters saved", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadSavedData() {
        val prefs = requireContext().getSharedPreferences("UserParams", Context.MODE_PRIVATE)
        binding.editAge.setText(prefs.getString("age", ""))
        binding.editWeight.setText(prefs.getString("weight", ""))
        binding.editHeight.setText(prefs.getString("height", ""))
        binding.spinnerGender.setSelection(prefs.getInt("gender_position", 0))
        conditionsList.clear()
        conditionsList.addAll(prefs.getStringSet("conditions", mutableSetOf())?.toMutableList() ?: mutableListOf())
        (binding.spinnerConditions.adapter as? ArrayAdapter<String>)?.notifyDataSetChanged()
    }

    private fun saveData() {
        val prefs = requireContext().getSharedPreferences("UserParams", Context.MODE_PRIVATE)
        with(prefs.edit()) {
            putString("age", binding.editAge.text.toString())
            putString("weight", binding.editWeight.text.toString())
            putString("height", binding.editHeight.text.toString())
            putInt("gender_position", binding.spinnerGender.selectedItemPosition)
            putStringSet("conditions", conditionsList.toSet())
            apply()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}