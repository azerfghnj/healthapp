package com.example.asclepius

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.asclepius.databinding.ItemConditionBinding

class ConditionsAdapter(
    private val conditions: MutableList<String>,
    private val onDelete: (String) -> Unit
) : RecyclerView.Adapter<ConditionsAdapter.ConditionViewHolder>() {

    inner class ConditionViewHolder(val binding: ItemConditionBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ConditionViewHolder {
        val binding = ItemConditionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ConditionViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ConditionViewHolder, position: Int) {
        val condition = conditions[position]
        holder.binding.tvCondition.text = condition
        holder.binding.btnDelete.setOnClickListener {
            onDelete(condition)
            conditions.removeAt(position)
            notifyItemRemoved(position)
        }
    }

    override fun getItemCount() = conditions.size
}
