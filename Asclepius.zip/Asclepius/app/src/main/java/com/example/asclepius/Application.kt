package com.example.asclepius

import android.app.Application
import com.google.firebase.FirebaseApp

class AsclepiusApp : Application() {
    override fun onCreate() {
        super.onCreate()
        FirebaseApp.initializeApp(this) // Initialize Firebase
    }
}