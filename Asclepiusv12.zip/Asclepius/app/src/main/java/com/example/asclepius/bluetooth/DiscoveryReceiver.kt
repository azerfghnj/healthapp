package com.example.asclepius.bluetooth

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeout
import android.os.Build

class DiscoveryReceiver(private val targetName: String) : BroadcastReceiver() {
    private val found = CompletableDeferred<BluetoothDevice?>()

    fun intentFilter(): IntentFilter = IntentFilter().apply {
        addAction(BluetoothDevice.ACTION_FOUND)
        addAction(android.bluetooth.BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
    }

    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            BluetoothDevice.ACTION_FOUND -> {
                val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE) as? BluetoothDevice
                }
                if (device?.name == targetName && !found.isCompleted) {
                    found.complete(device)
                }
            }
            android.bluetooth.BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                if (!found.isCompleted) found.complete(null)
            }
        }
    }

    suspend fun awaitResult(timeoutMs: Long): BluetoothDevice? =
        withTimeout(timeoutMs) { found.await() }
}
