pluginManagement {
    repositories {
        gradlePluginPortal()
        google()
        mavenCentral()

    }

    resolutionStrategy {
        eachPlugin {
            when (requested.id.id) {
                "com.android.application",
                "com.android.library" ->
                    useModule("com.android.tools.build:gradle:8.5.2")

                "org.jetbrains.kotlin.android",
                "org.jetbrains.kotlin.jvm" ->
                    useModule("org.jetbrains.kotlin:kotlin-gradle-plugin:1.9.24")

                "com.google.gms.google-services" ->
                    useModule("com.google.gms:google-services:4.4.2")

                "com.google.firebase.crashlytics" ->
                    useModule("com.google.firebase:firebase-crashlytics-gradle:2.9.9")

                else -> { /* leave others alone */ }
            }
        }
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.PREFER_SETTINGS)
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
        maven("https://jitpack.io") // 👈 Add this
    }
}

rootProject.name = "Asclepius"
include(":app")
