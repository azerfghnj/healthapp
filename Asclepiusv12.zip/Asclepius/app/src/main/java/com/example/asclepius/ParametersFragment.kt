package com.example.asclepius

import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContentProviderCompat.requireContext
import androidx.fragment.app.Fragment
import coil.load
import coil.transform.CircleCropTransformation
import com.example.asclepius.databinding.FragmentParametersBinding
import com.google.android.material.chip.Chip
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import java.io.ByteArrayOutputStream
import java.io.InputStream
import kotlin.collections.addAll
import kotlin.text.clear
import kotlin.text.get
import kotlin.toString

interface OnProfileImageUpdatedListener {
    fun onProfileImageUpdated(uri: Uri?)
}

class ParametersFragment : Fragment() {

    private var _binding: FragmentParametersBinding? = null
    private val binding get() = _binding!!

    private val conditionsList = mutableListOf<String>()
    private val allergiesList = mutableListOf<String>()
    private var profileImgUri: Uri? = null

    private fun encodeImageToBase64(context: Context, uri: Uri): String? {
        return try {
            val inputStream: InputStream? = context.contentResolver.openInputStream(uri)
            val originalBitmap = BitmapFactory.decodeStream(inputStream)

            // Resize the bitmap to a max width/height (e.g., 500px)
            val maxDimension = 500
            val scaledBitmap = if (originalBitmap.width > maxDimension || originalBitmap.height > maxDimension) {
                val ratio = originalBitmap.width.toFloat() / originalBitmap.height.toFloat()
                if (ratio > 1) {
                    Bitmap.createScaledBitmap(originalBitmap, maxDimension, (maxDimension / ratio).toInt(), true)
                } else {
                    Bitmap.createScaledBitmap(originalBitmap, (maxDimension * ratio).toInt(), maxDimension, true)
                }
            } else {
                originalBitmap
            }

            // Compress bitmap to JPEG with 70% quality
            val outputStream = ByteArrayOutputStream()
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 70, outputStream)
            val bytes = outputStream.toByteArray()
            Base64.encodeToString(bytes, Base64.DEFAULT)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    private val pickImageLauncher =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            uri?.let {
                profileImgUri = it

                // 1️⃣ Load instantly in the profileImage ImageView
                binding.profileImage.load(it) {
                    crossfade(true)
                    transformations(CircleCropTransformation())
                }

                // 2️⃣ Encode to Base64 with compression/resizing
                val base64 = encodeImageToBase64(requireContext(), it) ?: return@let

                // 3️⃣ Save locally (SharedPreferences)
                requireContext().getSharedPreferences("UserProfile", Context.MODE_PRIVATE)
                    .edit()
                    .putString("profileImageBase64", base64)
                    .putString("profileImage", it.toString()) // store URI too
                    .apply()

                // 4️⃣ Save to Firestore
                val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return@let
                FirebaseFirestore.getInstance().collection("users").document(uid)
                    .update("profileImageBase64", base64)

                // 5️⃣ Notify nav header immediately
                profileImageUpdatedListener?.onProfileImageUpdated(it)
            }
        }



    private var profileImageUpdatedListener: OnProfileImageUpdatedListener? = null

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnProfileImageUpdatedListener) {
            profileImageUpdatedListener = context
        }
    }

    override fun onDetach() {
        super.onDetach()
        profileImageUpdatedListener = null
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentParametersBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupSpinners()
        setupUiActions()
        loadSavedData()
    }

    // ------------------ UI SETUP ------------------
    private fun setupSpinners() {
        val genderAdapter = ArrayAdapter(
            requireContext(),
            R.layout.spinner_item,
            resources.getStringArray(R.array.gender_options)
        )
        binding.genderSpinner.adapter = genderAdapter

        val bloodAdapter = ArrayAdapter(
            requireContext(),
            R.layout.spinner_item,
            resources.getStringArray(R.array.blood_types)
        )
        binding.bloodSpinner.adapter = bloodAdapter
    }

    private fun setupUiActions() {
        // Profile Image
        binding.profileImage.setOnClickListener { pickImageLauncher.launch("image/*") }
        binding.btnUploadPhoto.setOnClickListener { pickImageLauncher.launch("image/*") }

        // Add conditions
        binding.addDiseaseButton.setOnClickListener {
            showSelectionDialog(
                title = "Select Medical Condition",
                common = listOf("Diabetes", "Hypertension", "Asthma", "Cardiac disease", "COPD"),
                targetList = conditionsList,
                containerId = binding.diseaseList
            )
        }

        // Add allergies
        binding.addAllergyButton.setOnClickListener {
            showSelectionDialog(
                title = "Select Allergy",
                common = listOf("Penicillin", "Peanuts", "Latex", "Pollen", "Dust"),
                targetList = allergiesList,
                containerId = binding.allergyList
            )
        }

        // Save button
        binding.saveButton.setOnClickListener {
            saveData {
                Toast.makeText(requireContext(), "Saved ✅", Toast.LENGTH_SHORT).show()
            }
        }

        // Logout button
        binding.logoutButton.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Logout")
                .setMessage("Save changes and logout?")
                .setPositiveButton("Yes") { _, _ ->
                    saveData {
                        // Always log out, even if Firestore save fails
                        FirebaseAuth.getInstance().signOut()
                        startActivity(Intent(requireContext(), LoginActivity::class.java))
                        requireActivity().finish()
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

    }

    // ------------------ DIALOGS ------------------
    private fun showSelectionDialog(
        title: String,
        common: List<String>,
        targetList: MutableList<String>,
        containerId: ViewGroup
    ) {
        val menu = common + "Add a new..."
        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle(title)
        builder.setItems(menu.toTypedArray()) { _, which ->
            if (which < common.size) {
                val item = common[which]
                if (!targetList.contains(item)) {
                    targetList.add(item)
                    addListItemChip(containerId, item, targetList)
                }
            } else {
                val input = EditText(requireContext())
                input.inputType = InputType.TYPE_CLASS_TEXT
                AlertDialog.Builder(requireContext())
                    .setTitle("Add New $title")
                    .setView(input)
                    .setPositiveButton("Add") { _, _ ->
                        val text = input.text.toString().trim()
                        if (text.isNotEmpty() && !targetList.contains(text)) {
                            targetList.add(text)
                            addListItemChip(containerId, text, targetList)
                        }
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        }
        builder.show()
    }

    private fun addListItemChip(container: ViewGroup, text: String, listRef: MutableList<String>) {
        val chip = Chip(requireContext()).apply {
            this.text = text
            isCloseIconVisible = true
            setTextColor(resources.getColor(android.R.color.black, null))
            chipBackgroundColor = android.content.res.ColorStateList.valueOf(
                resources.getColor(android.R.color.white, null)
            )

            // Existing close icon removal
            setOnCloseIconClickListener {
                listRef.remove(text)
                container.removeView(this)
            }

            // ✅ Long press to delete with confirmation
            setOnLongClickListener {
                AlertDialog.Builder(requireContext())
                    .setTitle("Delete Item")
                    .setMessage("Do you want to delete \"$text\"?")
                    .setPositiveButton("Yes") { _, _ ->
                        listRef.remove(text)
                        container.removeView(this)
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true // return true to consume the long click
            }
        }

        container.addView(chip)
    }


    // ------------------ SAVE DATA ------------------
    private fun saveData(onComplete: (() -> Unit)? = null) {
        val user = FirebaseAuth.getInstance().currentUser
        if (user == null) {
            if (isAdded) Toast.makeText(requireContext(), "Not logged in", Toast.LENGTH_SHORT).show()
            return
        }

        val uid = user.uid
        val db = FirebaseFirestore.getInstance()
        val docRef = db.collection("users").document(uid)

        val map = hashMapOf<String, Any?>(
            "name" to binding.nameEdit.text.toString().trim(),
            "age" to binding.ageEdit.text.toString().trim(),
            "gender" to binding.genderSpinner.selectedItem?.toString().orEmpty(),
            "bloodType" to binding.bloodSpinner.selectedItem?.toString().orEmpty(),
            "height" to binding.heightEdit.text.toString().trim(),
            "weight" to binding.weightEdit.text.toString().trim(),
            "conditions" to conditionsList,
            "allergies" to allergiesList
        )

        // Convert selected image to Base64 and store it
        if (profileImgUri != null) {
            val base64 = encodeImageToBase64(requireContext(), profileImgUri!!)
            if (base64 != null) {
                map["profileImageBase64"] = base64
            }
        }

        // Save to Firestore
        docRef.set(map, SetOptions.merge())
            .addOnSuccessListener {
                if (isAdded) saveLocally(map)
                onComplete?.invoke()
            }
            .addOnFailureListener {
                if (isAdded) {
                    saveLocally(map)
                    Toast.makeText(
                        requireContext(),
                        "Saved locally (Firestore failed): ${it.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
                // ✅ Ensure the callback (logout or save complete) still runs even if Firestore fails
                onComplete?.invoke()
            }

        profileImageUpdatedListener?.onProfileImageUpdated(profileImgUri)

    }

    // ------------------ IMAGE ENCODING ------------------
    private fun decodeBase64ToBitmap(base64: String): Bitmap? {
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }

    // ------------------ LOAD DATA ------------------
    private fun loadSavedData() {
        val prefs = requireContext().getSharedPreferences("UserProfile", Context.MODE_PRIVATE)

        // 1️⃣ Load local data first (SharedPreferences)
        binding.nameEdit.setText(prefs.getString("name", ""))
        binding.ageEdit.setText(prefs.getString("age", ""))
        setSpinnerSelection(
            binding.genderSpinner,
            resources.getStringArray(R.array.gender_options),
            prefs.getString("gender", "")
        )
        setSpinnerSelection(
            binding.bloodSpinner,
            resources.getStringArray(R.array.blood_types),
            prefs.getString("bloodType", "")
        )
        binding.heightEdit.setText(prefs.getString("height", ""))
        binding.weightEdit.setText(prefs.getString("weight", ""))

        conditionsList.clear()
        conditionsList.addAll(prefs.getStringSet("conditions", emptySet()) ?: emptySet())
        binding.diseaseList.removeAllViews()
        conditionsList.forEach { addListItemChip(binding.diseaseList, it, conditionsList) }

        allergiesList.clear()
        allergiesList.addAll(prefs.getStringSet("allergies", emptySet()) ?: emptySet())
        binding.allergyList.removeAllViews()
        allergiesList.forEach { addListItemChip(binding.allergyList, it, allergiesList) }

        // Load profile image from local if exists
        val localBase64 = prefs.getString("profileImageBase64", null)
        if (!localBase64.isNullOrEmpty()) {
            decodeBase64ToBitmap(localBase64)?.let {
                binding.profileImage.load(it) {
                    crossfade(true)
                    transformations(CircleCropTransformation())
                }
            }
        }

        // 2️⃣ Then fetch Firestore data, but only fill in missing fields
        val user = FirebaseAuth.getInstance().currentUser ?: return
        val uid = user.uid
        val db = FirebaseFirestore.getInstance()

        db.collection("users").document(uid).get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) {
                    // Only overwrite if local value is empty
                    if (binding.nameEdit.text.isNullOrEmpty())
                        binding.nameEdit.setText(doc.getString("name"))
                    if (binding.ageEdit.text.isNullOrEmpty())
                        binding.ageEdit.setText(doc.getString("age"))

                    setSpinnerSelection(
                        binding.genderSpinner,
                        resources.getStringArray(R.array.gender_options),
                        binding.genderSpinner.selectedItem?.toString().takeIf { it?.isNotEmpty() == true }
                            ?: doc.getString("gender")
                    )
                    setSpinnerSelection(
                        binding.bloodSpinner,
                        resources.getStringArray(R.array.blood_types),
                        binding.bloodSpinner.selectedItem?.toString().takeIf { it?.isNotEmpty() == true }
                            ?: doc.getString("bloodType")
                    )

                    if (binding.heightEdit.text.isNullOrEmpty())
                        binding.heightEdit.setText(doc.getString("height"))
                    if (binding.weightEdit.text.isNullOrEmpty())
                        binding.weightEdit.setText(doc.getString("weight"))

                    // Load conditions/allergies only if empty
                    if (conditionsList.isEmpty()) {
                        val cond = (doc.get("conditions") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                        conditionsList.addAll(cond)
                        binding.diseaseList.removeAllViews()
                        cond.forEach { addListItemChip(binding.diseaseList, it, conditionsList) }
                    }

                    if (allergiesList.isEmpty()) {
                        val allg = (doc.get("allergies") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                        allergiesList.addAll(allg)
                        binding.allergyList.removeAllViews()
                        allg.forEach { addListItemChip(binding.allergyList, it, allergiesList) }
                    }

                    // Load Firestore image only if no local image exists
                    if (localBase64.isNullOrEmpty()) {
                        val base64Image = doc.getString("profileImageBase64")
                        if (!base64Image.isNullOrEmpty()) {
                            decodeBase64ToBitmap(base64Image)?.let {
                                binding.profileImage.load(it) {
                                    crossfade(true)
                                    transformations(CircleCropTransformation())
                                }
                            }
                        }
                    }

                    // Save merged data locally
                    saveLocally(mapOf(
                        "name" to binding.nameEdit.text.toString(),
                        "age" to binding.ageEdit.text.toString(),
                        "gender" to binding.genderSpinner.selectedItem?.toString(),
                        "bloodType" to binding.bloodSpinner.selectedItem?.toString(),
                        "height" to binding.heightEdit.text.toString(),
                        "weight" to binding.weightEdit.text.toString(),
                        "conditions" to conditionsList,
                        "allergies" to allergiesList,
                        "profileImageBase64" to (localBase64 ?: doc.getString("profileImageBase64"))
                    ))
                }
            }
            .addOnFailureListener {
                Toast.makeText(requireContext(), "Using offline data", Toast.LENGTH_SHORT).show()
            }
    }

    private fun loadFromPrefs() {
        val prefs = requireContext().getSharedPreferences("UserProfile", Context.MODE_PRIVATE)
        binding.nameEdit.setText(prefs.getString("name", ""))
        binding.ageEdit.setText(prefs.getString("age", ""))
        setSpinnerSelection(
            binding.genderSpinner,
            resources.getStringArray(R.array.gender_options),
            prefs.getString("gender", "")
        )
        setSpinnerSelection(
            binding.bloodSpinner,
            resources.getStringArray(R.array.blood_types),
            prefs.getString("bloodType", "")
        )
        binding.heightEdit.setText(prefs.getString("height", ""))
        binding.weightEdit.setText(prefs.getString("weight", ""))

        conditionsList.clear()
        conditionsList.addAll(prefs.getStringSet("conditions", emptySet()) ?: emptySet())
        binding.diseaseList.removeAllViews()
        conditionsList.forEach { addListItemChip(binding.diseaseList, it, conditionsList) }

        allergiesList.clear()
        allergiesList.addAll(prefs.getStringSet("allergies", emptySet()) ?: emptySet())
        binding.allergyList.removeAllViews()
        allergiesList.forEach { addListItemChip(binding.allergyList, it, allergiesList) }

        // ✅ Prefer URI over Base64
        val uriString = prefs.getString("profileImage", null)
        if (!uriString.isNullOrEmpty()) {
            val uri = Uri.parse(uriString)
            binding.profileImage.load(uri) {
                crossfade(true)
                transformations(CircleCropTransformation())
            }
        } else {
            // fallback to Base64
            prefs.getString("profileImageBase64", null)?.let { base64 ->
                decodeBase64ToBitmap(base64)?.let {
                    binding.profileImage.load(it) {
                        crossfade(true)
                        transformations(CircleCropTransformation())
                    }
                }
            }
        }
    }
    // Save everything locally to SharedPreferences
    private fun saveLocally(map: Map<String, Any?>) {
        val prefs = requireContext().getSharedPreferences("UserProfile", Context.MODE_PRIVATE)
        with(prefs.edit()) {
            putString("name", map["name"] as? String)
            putString("age", map["age"] as? String)
            putString("gender", map["gender"] as? String)
            putString("bloodType", map["bloodType"] as? String)
            putString("height", map["height"] as? String)
            putString("weight", map["weight"] as? String)
            putStringSet("conditions", (map["conditions"] as? List<String>)?.toSet())
            putStringSet("allergies", (map["allergies"] as? List<String>)?.toSet())
            putString("profileImageBase64", map["profileImageBase64"] as? String)
            if (profileImgUri != null)
                putString("profileImage", profileImgUri.toString())

            apply()
        }
    }

    private fun setSpinnerSelection(
        spinner: android.widget.Spinner,
        options: Array<String>,
        value: String?
    ) {
        if (value == null) return
        val index = options.indexOf(value)
        if (index >= 0) spinner.setSelection(index)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
