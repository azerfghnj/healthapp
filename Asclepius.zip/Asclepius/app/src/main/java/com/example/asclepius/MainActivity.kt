package com.example.asclepius

import android.content.Intent
import android.os.Bundle
import android.view.MenuItem
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.fragment.app.Fragment
import com.example.asclepius.bluetooth.BluetoothFragment
import com.example.asclepius.bluetooth.BluetoothPermissionHelper
import com.example.asclepius.bluetooth.BluetoothService
import com.example.asclepius.databinding.ActivityMainBinding
import com.google.android.material.navigation.NavigationView

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    private lateinit var binding: ActivityMainBinding

    // --- NEW: Bluetooth enable launcher
    private val enableBtLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        // Start the service once BT is enabled (or even if user declined; service will retry)
        startBluetoothService()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toggle = ActionBarDrawerToggle(
            this, binding.drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        binding.drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        binding.navView.setNavigationItemSelectedListener(this)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.setHomeButtonEnabled(true)

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                    binding.drawerLayout.closeDrawer(GravityCompat.START)
                } else {
                    finish()
                }
            }
        })

        if (savedInstanceState == null) {
            loadFragment(HomeFragment())
            binding.navView.setCheckedItem(R.id.nav_home)
        }

        // --- NEW: Request BT permissions + enable flow + start service
        ensureBluetoothReady()
    }

    private fun ensureBluetoothReady() {
        if (!BluetoothPermissionHelper.hasAllPermissions(this)) {
            BluetoothPermissionHelper.requestPermissions(this, 1001)
        } else {
            BluetoothPermissionHelper.requestEnableBluetooth(enableBtLauncher)
        }
    }

    // Receive permission result
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001) {
            // Regardless of result, try to prompt enabling and start service; the service will handle retries.
            BluetoothPermissionHelper.requestEnableBluetooth(enableBtLauncher)
        }
    }

    private fun startBluetoothService() {
        val intent = Intent(this, BluetoothService::class.java)
        startForegroundService(intent)
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_home -> loadFragment(HomeFragment())
            R.id.nav_charts -> loadFragment(ChartsFragment())
            R.id.nav_chatbot -> {
                startActivity(Intent(this, ChatbotActivity::class.java))
                return true
            }
            R.id.nav_parameters -> loadFragment(ParametersFragment())
            R.id.nav_bluetooth -> loadFragment(BluetoothFragment())
        }
        binding.drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun loadFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            if (binding.drawerLayout.isDrawerOpen(GravityCompat.START)) {
                binding.drawerLayout.closeDrawer(GravityCompat.START)
            } else {
                binding.drawerLayout.openDrawer(GravityCompat.START)
            }
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
