package com.example.asclepius

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.asclepius.databinding.FragmentChartsBinding
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.storage.FirebaseStorage
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max

class ChartsFragment : Fragment() {

    private var _binding: FragmentChartsBinding? = null
    private val binding get() = _binding!!

    private val heartRateData = mutableListOf<Pair<Long, Float>>()
    private val spo2Data = mutableListOf<Pair<Long, Float>>()
    private val tempData = mutableListOf<Pair<Long, Float>>()
    private val fallData = mutableListOf<Pair<Long, Float>>() // 1.0 = fall, 0.0 otherwise

    private var startTime = System.currentTimeMillis()
    private var selectedSensor = "Heart Rate"
    private var selectedTimeRangeKey = "Last Hour"

    private val timeRangeMap = mapOf(
        "Last Hour" to 1 * 60 * 60 * 1000L,
        "Last 6 Hours" to 6 * 60 * 60 * 1000L,
        "Last 24 Hours" to 24 * 60 * 60 * 1000L,
        "Last Week" to 7 * 24 * 60 * 60 * 1000L
    )

    private val gson = Gson()

    // -----------------------------
    // Broadcast Receiver for FakeBluetoothService
    // -----------------------------
    private val btReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != "com.example.asclepius.BLUETOOTH_DATA") return

            val now = System.currentTimeMillis()

            val hr = intent.getIntExtra("heartRate", -1).toFloat()
            val spo2 = intent.getIntExtra("spo2", -1).toFloat()
            val temp = intent.getFloatExtra("temperature", -1f)
            val fall = intent.getBooleanExtra("fall", false)

            if (hr >= 0f) heartRateData.add(now to hr)
            if (spo2 >= 0f) spo2Data.add(now to spo2)
            if (temp >= 0f) tempData.add(now to temp)
            if (fall) fallData.add(now to 1f)

            trimOldData()
            saveData()
            refreshChart()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChartsBinding.inflate(inflater, container, false)
        binding.btnDownloadChart.setOnClickListener {
            saveChartToStorage()
        }

        loadData()
        setupSpinners()
        setupChartAppearance()

        return binding.root
    }

    private fun saveChartToStorage() {
        try {
            val prefs = requireContext().getSharedPreferences("UserProfile", Context.MODE_PRIVATE)
            val patientName = prefs.getString("name", "Unknown Patient")
            val conditions = prefs.getStringSet("conditions", emptySet())?.joinToString(", ") ?: "None"

            val bitmap = binding.chartView.chartBitmap
            val dateTime = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date())
            val filename = "Health_Report_${System.currentTimeMillis()}.pdf"

            val pdfDocument = android.graphics.pdf.PdfDocument()
            val pageInfo = android.graphics.pdf.PdfDocument.PageInfo.Builder(1080, 1920, 1).create()
            val page = pdfDocument.startPage(pageInfo)
            val canvas = page.canvas
            val paint = android.graphics.Paint()

            // Title and header
            paint.textSize = 46f
            paint.isFakeBoldText = true
            canvas.drawText("Health Monitoring Report", 50f, 100f, paint)

            paint.textSize = 28f
            paint.isFakeBoldText = false
            val lines = listOf(
                "Patient: $patientName",
                "Date: $dateTime",
                "Sensor: $selectedSensor",
                "Period: $selectedTimeRangeKey",
                "Conditions: $conditions"
            )
            var yPos = 180f
            lines.forEach {
                canvas.drawText(it, 50f, yPos, paint)
                yPos += 45f
            }

            // Chart
            val scaledBitmap = Bitmap.createScaledBitmap(bitmap, 950, 1000, true)
            canvas.drawBitmap(scaledBitmap, 50f, yPos + 20f, null)

            pdfDocument.finishPage(page)

            val resolver = requireContext().contentResolver
            val values = android.content.ContentValues().apply {
                put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, filename)
                put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
                put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, "Download/")
            }

            val uri = resolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                ?: throw Exception("Failed to create MediaStore entry")

            resolver.openOutputStream(uri)?.use { pdfDocument.writeTo(it) }
            pdfDocument.close()

            showMessage("✅ PDF saved successfully to Downloads.")

            // Upload to Firebase Storage
            val userId = FirebaseAuth.getInstance().currentUser?.uid ?: return
            val storageRef = FirebaseStorage.getInstance().reference.child("users/$userId/reports/$filename")
            storageRef.putFile(uri)
                .addOnSuccessListener {
                    showMessage("✅ PDF uploaded to Firebase Storage.")
                }
                .addOnFailureListener { e ->
                    showMessage("❌ Failed to upload PDF to Firebase: ${e.message}")
                }

        } catch (e: Exception) {
            e.printStackTrace()
            showMessage("❌ Failed to save PDF: ${e.message}")
        }
    }

    private fun setupSpinners() {
        val sensorOptions = resources.getStringArray(R.array.sensor_options).toList()
        val timeOptions = resources.getStringArray(R.array.period_options).toList()

        binding.spinnerSensor.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, sensorOptions).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        binding.spinnerPeriod.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_item, timeOptions).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }

        binding.spinnerSensor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedSensor = sensorOptions[position]
                refreshChart()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerPeriod.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedTimeRangeKey = timeOptions[position]
                trimOldData()
                refreshChart()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        binding.spinnerSensor.setSelection(0)
        binding.spinnerPeriod.setSelection(0)
    }

    private fun showMessage(msg: String) {
        android.widget.Toast.makeText(requireContext(), msg, android.widget.Toast.LENGTH_SHORT).show()
    }

    private fun setupChartAppearance() {
        binding.chartView.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            setPinchZoom(true)
            axisRight.isEnabled = false
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            legend.isEnabled = true
        }
    }

    private fun refreshChart() {
        val now = System.currentTimeMillis()
        val rangeMs = timeRangeMap[selectedTimeRangeKey] ?: (1 * 60 * 60 * 1000L)
        val cutoff = now - rangeMs

        val (rawList, label, colorRes) = when (selectedSensor) {
            "Heart Rate" -> Triple(heartRateData, "Heart Rate (bpm)", android.R.color.holo_blue_dark)
            "SpO2" -> Triple(spo2Data, "SpO₂ (%)", android.R.color.holo_green_dark)
            "Temperature" -> Triple(tempData, "Temperature (°C)", android.R.color.holo_orange_dark)
            "Fall Detection" -> Triple(fallData.map { it.first to it.second }, "Fall (1=fall)", android.R.color.holo_red_dark)
            else -> Triple(heartRateData, "Heart Rate (bpm)", android.R.color.holo_blue_dark)
        }

        val entries = rawList.filter { it.first >= cutoff }.map { (ts, value) ->
            Entry((ts - startTime) / 1000f, value)
        }

        val ds = LineDataSet(entries, label).apply {
            mode = LineDataSet.Mode.LINEAR
            lineWidth = if (selectedSensor == "Fall Detection") 1f else 2f
            setDrawCircles(selectedSensor == "Fall Detection")
            circleRadius = if (selectedSensor == "Fall Detection") 4f else 0f
            setDrawValues(false)
            color = ContextCompat.getColor(requireContext(), colorRes)
            circleHoleRadius = 0f
            if (selectedSensor == "Fall Detection") setCircleColor(ContextCompat.getColor(requireContext(), android.R.color.holo_red_dark))
        }

        val lineData = if (ds.entryCount == 0) {
            LineData(LineDataSet(listOf(Entry(0f, 0f)), label).apply {
                color = ContextCompat.getColor(requireContext(), android.R.color.darker_gray)
                setDrawCircles(false)
                setDrawValues(false)
            })
        } else LineData(ds)

        binding.chartView.data = lineData

        binding.chartView.xAxis.apply {
            setLabelCount(4, true)
            valueFormatter = TimeAxisFormatter(startTime)
        }

        binding.chartView.post { binding.chartView.invalidate() } // ensure runs on UI thread
    }

    private fun trimOldData() {
        val maxRange = timeRangeMap.values.maxOrNull() ?: (7L * 24 * 60 * 60 * 1000L)
        val keepFrom = System.currentTimeMillis() - maxRange

        fun <T> MutableList<Pair<Long, T>>.trim() {
            var i = 0
            while (i < size && this[i].first < keepFrom) i++
            if (i > 0) this.subList(0, i).clear()
        }

        heartRateData.trim()
        spo2Data.trim()
        tempData.trim()
        fallData.trim()
    }

    private fun saveData() {
        val prefs = requireContext().getSharedPreferences("SensorData", Context.MODE_PRIVATE)
        val editor = prefs.edit()
        editor.putString("heartRateData", gson.toJson(heartRateData))
        editor.putString("spo2Data", gson.toJson(spo2Data))
        editor.putString("tempData", gson.toJson(tempData))
        editor.putString("fallData", gson.toJson(fallData))
        editor.apply()
    }

    private fun loadData() {
        val prefs = requireContext().getSharedPreferences("SensorData", Context.MODE_PRIVATE)
        val type = object : TypeToken<MutableList<Pair<Long, Float>>>() {}.type

        val heartRateJson = prefs.getString("heartRateData", null)
        if (heartRateJson != null) {
            heartRateData.clear()
            heartRateData.addAll(gson.fromJson(heartRateJson, type))
        }

        val spo2Json = prefs.getString("spo2Data", null)
        if (spo2Json != null) {
            spo2Data.clear()
            spo2Data.addAll(gson.fromJson(spo2Json, type))
        }

        val tempJson = prefs.getString("tempData", null)
        if (tempJson != null) {
            tempData.clear()
            tempData.addAll(gson.fromJson(tempJson, type))
        }

        val fallJson = prefs.getString("fallData", null)
        if (fallJson != null) {
            fallData.clear()
            fallData.addAll(gson.fromJson(fallJson, type))
        }

        trimOldData()
        refreshChart()
    }

    override fun onResume() {
        super.onResume()
        startTime = System.currentTimeMillis()
        requireContext().registerReceiver(btReceiver, IntentFilter("com.example.asclepius.BLUETOOTH_DATA"))
        loadData()
        refreshChart()
    }

    override fun onPause() {
        super.onPause()
        saveData()
        try { requireContext().unregisterReceiver(btReceiver) } catch (_: Exception) {}
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private class TimeAxisFormatter(private val startTimeMillis: Long) : ValueFormatter() {
        private val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        override fun getFormattedValue(value: Float): String {
            val millisFromStart = (value * 1000f).toLong()
            return sdf.format(Date(startTimeMillis + millisFromStart))
        }
    }
}