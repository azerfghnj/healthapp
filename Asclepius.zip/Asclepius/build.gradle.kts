// top-level build.gradle.kts - minimal; settings.gradle.kts controls plugin resolution
plugins {
    // intentionally empty
}

tasks.register("clean", Delete::class) {
    delete(rootProject.buildDir)
}
