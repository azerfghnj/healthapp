package com.example.asclepius.bluetooth

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.asclepius.AnomalyDetector
import com.example.asclepius.UserParameters
import com.example.asclepius.data.DataUploader
import com.example.asclepius.data.VitalReading
import com.example.asclepius.DataRepository
import kotlinx.coroutines.*
import android.util.Log
import java.io.InputStream
import java.io.OutputStream
import java.util.*
import kotlin.math.roundToInt
import kotlin.coroutines.coroutineContext

class BluetoothService : Service() {

    companion object {
        private const val CHANNEL_ID = "BT_CHANNEL"
        private const val NOTIF_ID = 101
        private const val TARGET_DEVICE_NAME = "HC-06"
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val TAG = "BluetoothService"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    inner class LocalBinder : Binder() {
        fun getService(): BluetoothService = this@BluetoothService
        fun isConnected(): Boolean = socket?.isConnected == true
        fun write(bytes: ByteArray) {
            try { output?.write(bytes) } catch (e: Exception) { Log.w(TAG, "Write failed: ${e.message}") }
        }
    }
    private val binder = LocalBinder()

    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Asclepius BT service starting…"))

        serviceScope.launch {
            connectLoop()
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        serviceScope.cancel()
        closeSocket()
        super.onDestroy()
    }

    private fun sendUpdate(
        hr: Int,
        spo2: Int,
        temp: Float,
        fall: Boolean,
        systolic: Float? = null,
        diastolic: Float? = null
    ) {
        // Skip updates with no valid data
        if (hr < 0 && spo2 < 0 && temp <= 0f && systolic == null && diastolic == null) {
            Log.d(TAG, "Skipping invalid update: HR=$hr, SpO2=$spo2, Temp=$temp, Sys=$systolic, Dia=$diastolic")
            return
        }

        val intent = Intent("com.example.asclepius.BLUETOOTH_DATA")
        intent.putExtra("heartRate", hr)
        intent.putExtra("spo2", spo2)
        intent.putExtra("temperature", temp)
        intent.putExtra("fall", fall)
        if (systolic != null) intent.putExtra("systolic", systolic)
        if (diastolic != null) intent.putExtra("diastolic", diastolic)
        sendBroadcast(intent)

        val bpText = if (systolic != null && diastolic != null) {
            " | BP: ${systolic.roundToInt()}/${diastolic.roundToInt()} mmHg"
        } else ""
        updateNotification("HR: ${hr}bpm | SpO2: ${spo2}% | Temp: ${"%.1f".format(temp)}°C$bpText")
    }

    private suspend fun connectLoop() {
        val bluetoothManager = getSystemService(BluetoothManager::class.java)
        val adapter = bluetoothManager?.adapter ?: run {
            Log.e(TAG, "BluetoothManager or adapter is null")
            return
        }
        val detector = AnomalyDetector(applicationContext)
        val uploader = DataUploader()

        while (coroutineContext.isActive) {
            try {
                // Permission guard: service cannot request permissions, but must bail if missing
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    if (checkSelfPermission(android.Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                        Log.e(TAG, "Missing BLUETOOTH_CONNECT permission")
                        updateNotification("Missing BLUETOOTH_CONNECT permission")
                        delay(2000)
                        continue
                    }
                }

                if (!adapter.isEnabled) {
                    Log.d(TAG, "Bluetooth disabled, waiting...")
                    updateNotification("Waiting for Bluetooth to be enabled…")
                    delay(2000)
                    continue
                }

                // Log bonded devices for debugging
                Log.d(TAG, "Bonded devices: ${adapter.bondedDevices.joinToString { it.name ?: it.address }}")

                val bonded = adapter.bondedDevices.firstOrNull { it.name == TARGET_DEVICE_NAME }
                val device = bonded ?: discoverDevice(adapter, TARGET_DEVICE_NAME, 10_000L)

                if (device != null) {
                    Log.d(TAG, "Connecting to ${device.name} (${device.address})")
                    updateNotification("Connecting to ${device.name}…")
                    connectToDevice(device)
                    Log.d(TAG, "Connected to ${device.name}")
                    updateNotification("Connected to ${device.name}")
                    readPump(detector, uploader)
                } else {
                    Log.d(TAG, "Device $TARGET_DEVICE_NAME not found")
                    updateNotification("Device $TARGET_DEVICE_NAME not found, retrying…")
                    delay(5_000)
                }
            } catch (t: Throwable) {
                Log.e(TAG, "Connection error: ${t.message}", t)
                updateNotification("BT error: ${t.message ?: t.javaClass.simpleName}. Reconnecting…")
                delay(2_000)
            } finally {
                closeSocket()
            }
        }
    }

    private suspend fun discoverDevice(adapter: BluetoothAdapter, targetName: String, timeoutMs: Long): BluetoothDevice? =
        withContext(Dispatchers.IO) {
            // Permission guard for scan on newer Android versions
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (checkSelfPermission(android.Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) {
                    Log.e(TAG, "Missing BLUETOOTH_SCAN permission")
                    return@withContext null
                }
            }

            val found = CompletableDeferred<BluetoothDevice?>()
            val receiver = object : android.content.BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent) {
                    val action = intent.action
                    if (action == BluetoothDevice.ACTION_FOUND) {
                        val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE) as? BluetoothDevice
                        }
                        val name = device?.name
                        if (name != null) Log.d(TAG, "Discovery found: $name / ${device.address}")
                        if (device?.name == targetName && !found.isCompleted) {
                            found.complete(device)
                        }
                    } else if (action == BluetoothAdapter.ACTION_DISCOVERY_FINISHED) {
                        if (!found.isCompleted) found.complete(null)
                    }
                }
            }

            val filter = android.content.IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            }

            try {
                registerReceiver(receiver, filter)
                if (adapter.isDiscovering) adapter.cancelDiscovery()
                adapter.startDiscovery()
                return@withContext withTimeoutOrNull(timeoutMs) { found.await() }
            } finally {
                try { adapter.cancelDiscovery() } catch (_: Exception) {}
                try { unregisterReceiver(receiver) } catch (_: Exception) {}
            }
        }

    private fun connectToDevice(device: BluetoothDevice) {
        try {
            val bluetoothManager = getSystemService(BluetoothManager::class.java)
            bluetoothManager?.adapter?.cancelDiscovery()

            // Primary attempt (secure)
            try {
                socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                socket!!.connect()
            } catch (e1: Exception) {
                Log.w(TAG, "Secure connect failed: ${e1.message}; trying insecure/fallback")
                // Try insecure socket (no pairing requirement)
                try {
                    val m = device.javaClass.getMethod("createInsecureRfcommSocketToServiceRecord", UUID::class.java)
                    socket = m.invoke(device, SPP_UUID) as BluetoothSocket
                    socket!!.connect()
                } catch (e2: Exception) {
                    Log.w(TAG, "Insecure connect failed: ${e2.message}; trying reflection fallback")
                    // Reflection fallback (older devices)
                    val m = device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                    socket = m.invoke(device, 1) as BluetoothSocket
                    socket!!.connect()
                }
            }

            input = socket!!.inputStream
            output = socket!!.outputStream
        } catch (ex: Exception) {
            Log.e(TAG, "connectToDevice final failure: ${ex.message}", ex)
            closeSocket()
            throw ex
        }
    }

    private fun readPump(detector: AnomalyDetector, uploader: DataUploader) {
        val buf = ByteArray(512)
        val sb = StringBuilder()

        try {
            while (serviceScope.coroutineContext.isActive && socket?.isConnected == true) {
                val n = input?.read(buf) ?: break
                if (n <= 0) break

                val chunk = String(buf, 0, n)
                Log.d(TAG, "raw chunk ($n bytes): ${chunk.replace("\r","\\r").replace("\n","\\n")}")

                sb.append(chunk)

                // Accept \n or \r as line endings
                var newlineIndex = sb.indexOf("\n")
                if (newlineIndex == -1) newlineIndex = sb.indexOf("\r")

                while (newlineIndex != -1) {
                    val rawLine = sb.substring(0, newlineIndex).trim()
                    sb.delete(0, newlineIndex + 1)

                    if (rawLine.isNotEmpty()) {
                        Log.d(TAG, "Received line: <$rawLine>")
                        try {
                            parseLine(rawLine)?.let { parsed ->
                                Log.d(TAG, "Parsed data: $parsed")

                                // Load user parameters from SharedPreferences
                                val userParams = UserParameters(
                                    age = getUserAge(),
                                    gender = getUserGender(),
                                    height = getUserHeight(),
                                    weight = getUserWeight(),
                                    conditions = getUserConditions()
                                )

                                // Detect anomalies
                                try {
                                    detector.detectAnomaly(
                                        parsed.hr ?: 0f,
                                        parsed.spo2 ?: 0f,
                                        parsed.temp ?: 0f,
                                        userParams
                                    )
                                } catch (e: Exception) {
                                    Log.e(TAG, "Anomaly detection error", e)
                                }

                                // Prepare data for UI updates
                                val hrInt = parsed.hr?.roundToInt() ?: -1
                                val spo2Int = parsed.spo2?.roundToInt() ?: -1
                                val temp = parsed.temp ?: -1f
                                sendUpdate(hrInt, spo2Int, temp, parsed.fall, parsed.systolic, parsed.diastolic)

                                // Save locally
                                try {
                                    parsed.hr?.let { DataRepository.addHeartRate(it) }
                                    parsed.spo2?.let { DataRepository.addSpo2(it) }
                                    parsed.temp?.let { DataRepository.addTemp(it) }
                                    if (parsed.fall) DataRepository.addFall()
                                    if (parsed.systolic != null && parsed.diastolic != null) {
                                        DataRepository.addBloodPressure(parsed.systolic, parsed.diastolic)
                                    }
                                } catch (e: Exception) {
                                    Log.e(TAG, "Data repository error", e)
                                }

                                // Upload to Firestore
                                serviceScope.launch {
                                    try {
                                        val reading = VitalReading(
                                            heartRate = parsed.hr,
                                            spo2 = parsed.spo2,
                                            temperature = parsed.temp,
                                            fall = parsed.fall,
                                            systolic = parsed.systolic,
                                            diastolic = parsed.diastolic
                                        )
                                        uploader.upload(userId = "demoUser123", reading = reading)
                                    } catch (e: Exception) {
                                        Log.e(TAG, "Upload error", e)
                                    }
                                }
                            } ?: run {
                                Log.d(TAG, "parseLine returned null for: <$rawLine>")
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing line: $rawLine", e)
                        }
                    }

                    newlineIndex = sb.indexOf("\n")
                    if (newlineIndex == -1) newlineIndex = sb.indexOf("\r")
                }

                // Safety: parse buffer if too large without newline
                if (sb.length > 512) {
                    val partial = sb.toString().trim()
                    sb.clear()
                    if (partial.isNotEmpty()) {
                        Log.w(TAG, "Buffer grew large without newline, parsing partial: ${partial.take(200)}...")
                        try {
                            parseLine(partial)?.let { parsed ->
                                Log.d(TAG, "Parsed partial data: $parsed")
                                val hrInt = parsed.hr?.roundToInt() ?: -1
                                val spo2Int = parsed.spo2?.roundToInt() ?: -1
                                val temp = parsed.temp ?: -1f
                                sendUpdate(hrInt, spo2Int, temp, parsed.fall, parsed.systolic, parsed.diastolic)
                            }
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing partial buffer", e)
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Read pump error", e)
        }
    }

    private fun getUserAge(): Int {
        val prefs = getSharedPreferences("UserParams", Context.MODE_PRIVATE)
        return prefs.getString("age", "30")?.toIntOrNull() ?: 30
    }

    private fun getUserGender(): String {
        val prefs = getSharedPreferences("UserParams", Context.MODE_PRIVATE)
        return prefs.getString("gender", "M") ?: "M"
    }

    private fun getUserHeight(): Float {
        val prefs = getSharedPreferences("UserParams", Context.MODE_PRIVATE)
        return prefs.getString("height", "175")?.toFloatOrNull() ?: 175f
    }

    private fun getUserWeight(): Float {
        val prefs = getSharedPreferences("UserParams", Context.MODE_PRIVATE)
        return prefs.getString("weight", "70")?.toFloatOrNull() ?: 70f
    }

    private fun getUserConditions(): Set<String> {
        val prefs = getSharedPreferences("UserParams", Context.MODE_PRIVATE)
        return prefs.getStringSet("conditions", emptySet()) ?: emptySet()
    }

    private fun closeSocket() {
        try { input?.close() } catch (_: Exception) {}
        try { output?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        input = null; output = null; socket = null
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Asclepius Bluetooth", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Asclepius Bluetooth")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }
}
