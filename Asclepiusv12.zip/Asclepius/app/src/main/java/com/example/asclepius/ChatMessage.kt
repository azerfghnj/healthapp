package com.example.asclepius

data class ChatMessage(
    val message: String,
    val isSentByUser: Boolean,
    val timestamp: Long = System.currentTimeMillis()
)
