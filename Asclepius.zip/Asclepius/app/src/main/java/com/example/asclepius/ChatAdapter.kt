package com.example.asclepius

import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.asclepius.ChatMessage
import android.widget.LinearLayout

class ChatAdapter(private val messages: List<ChatMessage>) :
    RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

    class ChatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val messageText: TextView = itemView.findViewById(R.id.messageText)
        val messageContainer: View = itemView.findViewById(R.id.messageContainer)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat_message, parent, false)
        return ChatViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val message = messages[position]
        holder.messageText.text = message.message

        // Cast to LinearLayout.LayoutParams since messageContainer is a LinearLayout
        val layoutParams = holder.messageContainer.layoutParams as LinearLayout.LayoutParams
        if (message.isSentByUser) {
            layoutParams.gravity = Gravity.END
            holder.messageContainer.background = holder.itemView.context.getDrawable(R.drawable.rounded_user_message_bubble)
        } else {
            layoutParams.gravity = Gravity.START
            holder.messageContainer.background = holder.itemView.context.getDrawable(R.drawable.rounded_bot_message_bubble)
        }
        holder.messageContainer.layoutParams = layoutParams
    }

    override fun getItemCount() = messages.size

    fun addMessage(message: ChatMessage) {
        // Note: This adapter uses an immutable list; update logic in activity
    }
}