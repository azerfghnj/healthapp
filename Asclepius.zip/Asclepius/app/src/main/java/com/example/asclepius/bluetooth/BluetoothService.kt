package com.example.asclepius.bluetooth

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.example.asclepius.AnomalyDetector
import com.example.asclepius.UserParameters
import com.example.asclepius.data.DataUploader
import com.example.asclepius.data.VitalReading
import kotlinx.coroutines.*
import java.io.InputStream
import java.io.OutputStream
import java.util.*
import kotlin.coroutines.coroutineContext

/**
 * Foreground Service:
 * - finds/connects to classic SPP device (HC-06 by default)
 * - reads lines from socket (blocking read) on Dispatchers.IO
 * - parses lines, detects anomalies and uploads readings (best-effort)
 */
class BluetoothService : Service() {

    companion object {
        private const val CHANNEL_ID = "BT_CHANNEL"
        private const val NOTIF_ID = 101
        private const val TARGET_DEVICE_NAME = "HC-06"
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    // Use explicit IO dispatcher for blocking socket reads
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    inner class LocalBinder : Binder() {
        fun getService(): BluetoothService = this@BluetoothService
        fun isConnected(): Boolean = socket?.isConnected == true
        fun write(bytes: ByteArray) {
            try {
                output?.write(bytes)
            } catch (_: Exception) { /* ignore */ }
        }
    }
    private val binder = LocalBinder()

    // Socket and streams (nullable)
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        startForeground(NOTIF_ID, buildNotification("Asclepius BT service starting…"))

        // launch the connect/reconnect loop on the IO dispatcher
        serviceScope.launch {
            connectLoop()
        }
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onDestroy() {
        serviceScope.cancel()
        closeSocket()
        super.onDestroy()
    }

    // --- Main connect/reconnect loop
    private suspend fun connectLoop() {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return
        val detector = AnomalyDetector(applicationContext)
        val uploader = DataUploader()

        // Use coroutineContext.isActive explicitly to avoid ambiguity
        while (coroutineContext.isActive) {
            try {
                if (!adapter.isEnabled) {
                    updateNotification("Waiting for Bluetooth to be enabled…")
                    delay(2000)
                    continue
                }

                // Prefer bonded device (fast). If not found, run discovery.
                val bonded = adapter.bondedDevices.firstOrNull { it.name == TARGET_DEVICE_NAME }
                val device = bonded ?: discoverDevice(adapter, TARGET_DEVICE_NAME, 10_000L)

                if (device != null) {
                    updateNotification("Connecting to ${device.name}…")
                    connectToDevice(device)
                    updateNotification("Connected to ${device.name}")
                    // readPump is blocking but we are on Dispatchers.IO (serviceScope)
                    readPump(detector, uploader)
                } else {
                    updateNotification("Device $TARGET_DEVICE_NAME not found, retrying…")
                    delay(5_000)
                }
            } catch (t: Throwable) {
                updateNotification("BT error: ${t.message ?: t.javaClass.simpleName}. Reconnecting…")
                delay(2_000)
            } finally {
                closeSocket()
            }
        }
    }

    // Discover device by name (suspend until found or timeout)
    private suspend fun discoverDevice(adapter: BluetoothAdapter, targetName: String, timeoutMs: Long): BluetoothDevice? =
        withContext(Dispatchers.IO) {
            val found = CompletableDeferred<BluetoothDevice?>()
            val receiver = object : android.content.BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    val action = intent?.action
                    if (action == BluetoothDevice.ACTION_FOUND) {
                        // Support API 33+ safely:
                        val device: BluetoothDevice? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                            intent?.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                        } else {
                            @Suppress("DEPRECATION")
                            intent?.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE) as? BluetoothDevice
                        }
                        if (device?.name == targetName && !found.isCompleted) {
                            found.complete(device)
                        }
                    } else if (action == BluetoothAdapter.ACTION_DISCOVERY_FINISHED) {
                        if (!found.isCompleted) found.complete(null)
                    }
                }
            }

            val filter = android.content.IntentFilter().apply {
                addAction(BluetoothDevice.ACTION_FOUND)
                addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
            }

            try {
                registerReceiver(receiver, filter)
                if (adapter.isDiscovering) adapter.cancelDiscovery()
                adapter.startDiscovery()
                return@withContext withTimeoutOrNull(timeoutMs) { found.await() }
            } finally {
                try { adapter.cancelDiscovery() } catch (_: Exception) {}
                try { unregisterReceiver(receiver) } catch (_: Exception) {}
            }
        }

    private fun connectToDevice(device: BluetoothDevice) {
        try {
            BluetoothAdapter.getDefaultAdapter()?.cancelDiscovery()
            socket = device.createRfcommSocketToServiceRecord(SPP_UUID)
            socket!!.connect()
            input = socket!!.inputStream
            output = socket!!.outputStream
        } catch (ex: Exception) {
            closeSocket()
            throw ex
        }
    }

    /**
     * readPump: blocking read loop that splits by newline and processes lines.
     * This runs on Dispatchers.IO via serviceScope.launch -> connectLoop()
     */
    private fun readPump(detector: AnomalyDetector, uploader: DataUploader) {
        val buf = ByteArray(512)
        val sb = StringBuilder()

        try {
            // Check cancellation using the scope's coroutineContext
            while (serviceScope.coroutineContext.isActive && socket?.isConnected == true) {
                val n = input?.read(buf) ?: break
                if (n <= 0) break

                sb.append(String(buf, 0, n))
                var newlineIndex = sb.indexOf("\n")
                while (newlineIndex != -1) {
                    val rawLine = sb.substring(0, newlineIndex).trim()
                    sb.delete(0, newlineIndex + 1)

                    try {
                        parseLine(rawLine)?.let { parsed ->
                            // Local anomaly detection (best-effort)
                            try {
                                detector.detectAnomaly(
                                    parsed.hr,
                                    parsed.spo2,
                                    parsed.temp,
                                    UserParameters(age = 30, gender = "M", height = 175f, weight = 70f, conditions = emptySet())
                                )
                            } catch (_: Exception) { /* ignore detection errors */ }

                            // Firestore upload asynchronously (best-effort)
                            serviceScope.launch {
                                try {
                                    val reading = VitalReading(
                                        heartRate = parsed.hr,
                                        spo2 = parsed.spo2,
                                        temperature = parsed.temp,
                                        fall = parsed.fall
                                    )
                                    uploader.upload(userId = "demoUser123", reading = reading)
                                } catch (_: Exception) {
                                    // ignore upload failures
                                }
                            }
                        }
                    } catch (_: Exception) {
                        // ignore per-line errors
                    }
                    newlineIndex = sb.indexOf("\n")
                }
            }
        } catch (_: Exception) {
            // read loop error -> break and allow reconnect
        }
    }

    private fun closeSocket() {
        try { input?.close() } catch (_: Exception) {}
        try { output?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        input = null; output = null; socket = null
    }

    // Notification helpers
    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Asclepius Bluetooth", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
    }

    private fun buildNotification(text: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setContentTitle("Asclepius Bluetooth")
            .setContentText(text)
            .setOngoing(true)
            .build()

    private fun updateNotification(text: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIF_ID, buildNotification(text))
    }
}
