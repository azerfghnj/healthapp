package com.example.asclepius

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.VibratorManager
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.asclepius.databinding.FragmentChartsBinding
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast

class ChartsFragment : Fragment(), SensorEventListener {
    private var _binding: FragmentChartsBinding? = null
    private val binding get() = _binding!!
    private val CHANNEL_ID = "FallDetectionChannel"
    private val NOTIFICATION_ID = 1
    private lateinit var sensorManager: SensorManager
    private var heartRateSensor: Sensor? = null
    private var tempSensor: Sensor? = null
    private val REQUEST_SENSOR_PERMISSIONS = 3

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentChartsBinding.inflate(inflater, container, false)
        createNotificationChannel()
        setupSensors()
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.chartHeartRate.apply {
            data = LineData(LineDataSet(mutableListOf(Entry(0f, 0f)), "Heart Rate"))
            description.text = "Heart Rate (bpm)"
            invalidate()
        }
        binding.chartSpo2.apply {
            data = LineData(LineDataSet(mutableListOf(Entry(0f, 0f)), "SpO2"))
            description.text = "SpO2 (%)"
            invalidate()
        }
        binding.chartTemperature.apply {
            data = LineData(LineDataSet(mutableListOf(Entry(0f, 0f)), "Temperature"))
            description.text = "Temperature (°C)"
            invalidate()
        }

        binding.spinnerTimeRange.adapter = ArrayAdapter(
            requireContext(),
            android.R.layout.simple_spinner_item,
            resources.getStringArray(R.array.time_ranges)
        ).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
    }

    private fun setupSensors() {
        sensorManager = requireContext().getSystemService(Context.SENSOR_SERVICE) as SensorManager

        heartRateSensor = sensorManager.getDefaultSensor(Sensor.TYPE_HEART_RATE)
        tempSensor = sensorManager.getDefaultSensor(Sensor.TYPE_AMBIENT_TEMPERATURE)
        if (heartRateSensor == null || tempSensor == null) {
            Toast.makeText(context, "Some sensors not available", Toast.LENGTH_SHORT).show()
        }

        checkSensorPermissions()
    }

    private fun checkSensorPermissions() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.BODY_SENSORS) != PackageManager.PERMISSION_GRANTED) {
            requestSensorPermission()
        } else {
            registerSensors()
        }
    }

    private fun requestSensorPermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(requireActivity(), Manifest.permission.BODY_SENSORS)) {
            AlertDialog.Builder(requireContext())
                .setTitle("Permission Needed")
                .setMessage("This app needs body sensors permission to monitor health data.")
                .setPositiveButton("Grant") { _, _ ->
                    ActivityCompat.requestPermissions(
                        requireActivity(),
                        arrayOf(Manifest.permission.BODY_SENSORS),
                        REQUEST_SENSOR_PERMISSIONS
                    )
                }
                .setNegativeButton("Deny") { dialog, _ -> dialog.dismiss() }
                .create()
                .show()
        } else {
            ActivityCompat.requestPermissions(
                requireActivity(),
                arrayOf(Manifest.permission.BODY_SENSORS),
                REQUEST_SENSOR_PERMISSIONS
            )
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == REQUEST_SENSOR_PERMISSIONS) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(context, "Sensor permission granted", Toast.LENGTH_SHORT).show()
                registerSensors()
            } else {
                Toast.makeText(context, "Sensor permission denied. Some features may not work.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun registerSensors() {
        heartRateSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        tempSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event?.let {
            when (it.sensor.type) {
                Sensor.TYPE_HEART_RATE -> {
                    val heartRate = it.values[0]
                    updateChart(binding.chartHeartRate, "Heart Rate", heartRate)
                    checkAnomaly(heartRate = heartRate)
                }
                Sensor.TYPE_AMBIENT_TEMPERATURE -> {
                    val temp = it.values[0]
                    updateChart(binding.chartTemperature, "Temperature", temp)
                    checkAnomaly(temp = temp)
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    private fun updateChart(chart: com.github.mikephil.charting.charts.LineChart, label: String, value: Float) {
        val dataSet = chart.data.getDataSetByLabel(label, true) as? LineDataSet ?: LineDataSet(mutableListOf(), label)
        dataSet.values.add(Entry(dataSet.values.size.toFloat(), value))
        chart.data.notifyDataChanged()
        chart.notifyDataSetChanged()
        chart.invalidate()
    }

    private fun createNotificationChannel() {
        val name = "Fall Detection"
        val importance = NotificationManager.IMPORTANCE_HIGH
        val channel = NotificationChannel(CHANNEL_ID, name, importance).apply {
            enableVibration(true)
        }
        val notificationManager = requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.createNotificationChannel(channel)
    }

    private fun checkAnomaly(temp: Float? = null, heartRate: Float? = null, spo2: Float? = null, fallDetected: Int? = null) {
        if (isAdded) { // Check if fragment is attached
            val anomalies = mutableListOf<String>()
            temp?.let { if (it < 36 || it > 38.5) anomalies.add("Temperature: ${it}°C (optimal: 36.5-37.5°C)") }
            heartRate?.let { if (it < 50 || it > 110) anomalies.add("Heart Rate: ${it}bpm (optimal: 60-100bpm)") }
            spo2?.let { if (it < 90) anomalies.add("SpO2: ${it}% (optimal: 95-100%)") }
            fallDetected?.let { if (it == 1) anomalies.add("Fall Detected") }

            if (anomalies.isNotEmpty() || fallDetected == 1) {
                val message = if (fallDetected == 1) "🚨 Fall Detected!" else "⚠️ Anomalies Detected:\n${anomalies.joinToString("\n")}"
                showNotification(message)
            }
        }
    }

    private fun showNotification(message: String) {
        if (isAdded) { // Ensure context is available
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = requireContext().getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                requireContext().getSystemService(Context.VIBRATOR_SERVICE) as android.os.Vibrator
            }
            val vibrationEffect = VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator.vibrate(vibrationEffect)
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(500)
            }

            val notificationManager = requireContext().getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            val notification = androidx.core.app.NotificationCompat.Builder(requireContext(), CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_alert)
                .setContentTitle("Health Alert")
                .setContentText(message)
                .setPriority(androidx.core.app.NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .build()

            notificationManager.notify(NOTIFICATION_ID, notification)
        }
    }

    override fun onResume() {
        super.onResume()
        registerSensors()
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        sensorManager.unregisterListener(this)
        _binding = null
    }
}