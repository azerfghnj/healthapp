package com.example.asclepius

import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

class ChatAdapter(private val messages: MutableList<ChatMessage>) :
    RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

    class ChatViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val messageText: TextView = itemView.findViewById(R.id.messageText)
        val messageContainer: View = itemView.findViewById(R.id.messageContainer)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_chat_message, parent, false)
        return ChatViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val message = messages[position]
        holder.messageText.text = message.message

        // Ensure container uses LinearLayout.LayoutParams if it's a LinearLayout child
        val lp = holder.messageContainer.layoutParams
        if (lp is LinearLayout.LayoutParams) {
            if (message.isSentByUser) {
                lp.gravity = Gravity.END
                holder.messageContainer.background =
                    ContextCompat.getDrawable(holder.itemView.context, R.drawable.rounded_user_message_bubble)
            } else {
                lp.gravity = Gravity.START
                holder.messageContainer.background =
                    ContextCompat.getDrawable(holder.itemView.context, R.drawable.rounded_bot_message_bubble)
            }
            holder.messageContainer.layoutParams = lp
        } else {
            // Fallback: set alignment via translation or visibility if not LinearLayout params
            // (keeps layout robust)
            if (message.isSentByUser) {
                holder.messageContainer.textAlignment = View.TEXT_ALIGNMENT_VIEW_END
            } else {
                holder.messageContainer.textAlignment = View.TEXT_ALIGNMENT_VIEW_START
            }
        }
    }

    override fun getItemCount() = messages.size

    /** Add message and notify adapter */
    fun addMessage(message: ChatMessage) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }

    /** Remove item safely by position */
    fun removeAt(position: Int) {
        if (position >= 0 && position < messages.size) {
            messages.removeAt(position)
            notifyItemRemoved(position)
        }
    }
}
