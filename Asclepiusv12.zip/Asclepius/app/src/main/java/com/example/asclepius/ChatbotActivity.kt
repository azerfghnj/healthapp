package com.example.asclepius

import android.content.Context
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.asclepius.databinding.ActivityChatbotBinding
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.Content
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.google.ai.client.generativeai.type.TextPart

class ChatbotActivity : AppCompatActivity() {

    private lateinit var binding: ActivityChatbotBinding
    private val chatMessages = mutableListOf<ChatMessage>()
    private lateinit var chatAdapter: ChatAdapter
    private var chatSession: com.google.ai.client.generativeai.Chat? = null
    private val TAG = "ChatbotActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityChatbotBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupListeners()
        initChatSession()
    }

    private fun setupRecyclerView() {
        chatAdapter = ChatAdapter(chatMessages)
        binding.rvChat.layoutManager = LinearLayoutManager(this).apply { stackFromEnd = true }
        binding.rvChat.adapter = chatAdapter

        chatAdapter.addMessage(ChatMessage("👋 Hi! I’m your personal health assistant.", false))
        chatAdapter.addMessage(ChatMessage("💬 How can I support you today?", false))
    }

    private fun setupListeners() {
        binding.btnSend.setOnClickListener { sendMessage() }

        binding.etMessage.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEND) {
                sendMessage()
                true
            } else false
        }

        binding.topAppBar?.setNavigationOnClickListener {
            onBackPressedDispatcher.onBackPressed()
        }
    }

    // ---------------- CHAT SETUP ----------------
    private fun initChatSession() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val apiKey = BuildConfig.GEMINI_API_KEY
                if (apiKey.isEmpty()) {
                    withContext(Dispatchers.Main) {
                        chatAdapter.addMessage(ChatMessage("⚠️ Missing Gemini API key.", false))
                    }
                    return@launch
                }

                val genAI = GenerativeModel(
                    modelName = "gemini-2.5-flash",
                    apiKey = apiKey
                )

                val profile = loadUserProfile()
                val systemPrompt = buildSystemPrompt(profile)

                chatSession = genAI.startChat(
                    history = listOf(
                        Content(
                            role = "user",
                            parts = listOf(TextPart(systemPrompt))
                        )
                    )
                )

                withContext(Dispatchers.Main) {
                    chatAdapter.addMessage(ChatMessage("✅ Personalized chat ready, ${profile.name ?: "user"}!", false))
                }

            } catch (e: Exception) {
                Log.e(TAG, "Chat init error", e)
                withContext(Dispatchers.Main) {
                    chatAdapter.addMessage(ChatMessage("❌ Error initializing chat: ${e.message}", false))
                }
            }
        }
    }

    // ---------------- SEND MESSAGE ----------------
    private fun sendMessage() {
        val message = binding.etMessage.text?.toString()?.trim().orEmpty()
        if (message.isEmpty()) return

        chatAdapter.addMessage(ChatMessage(message, true))
        binding.etMessage.text?.clear()
        chatAdapter.addMessage(ChatMessage("...", false))
        val loadingIndex = chatAdapter.itemCount - 1

        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val chat = chatSession ?: run {
                    withContext(Dispatchers.Main) {
                        chatAdapter.removeAt(loadingIndex)
                        chatAdapter.addMessage(ChatMessage("Session not initialized yet. Try again.", false))
                    }
                    return@launch
                }

                val response = chat.sendMessage(message)
                val reply = response.text ?: "Sorry, I didn’t quite understand that."

                withContext(Dispatchers.Main) {
                    chatAdapter.removeAt(loadingIndex)
                    chatAdapter.addMessage(ChatMessage(reply, false))
                }

            } catch (e: Exception) {
                Log.e(TAG, "Send error", e)
                withContext(Dispatchers.Main) {
                    chatAdapter.removeAt(loadingIndex)
                    chatAdapter.addMessage(ChatMessage("⚠️ Error: ${e.message}", false))
                }
            }
        }
    }

    // ---------------- PROFILE ----------------
    private data class UserProfile(
        val name: String?,
        val age: String?,
        val gender: String?,
        val bloodType: String?,
        val height: String?,
        val weight: String?,
        val conditions: Set<String>?,
        val allergies: Set<String>?,
        val bmi: String
    )

    private fun loadUserProfile(): UserProfile {
        val prefs = getSharedPreferences("UserProfile", Context.MODE_PRIVATE)

        val name = prefs.getString("name", null)
        val age = prefs.getString("age", null)
        val gender = prefs.getString("gender", null)
        val bloodType = prefs.getString("bloodType", null)
        val height = prefs.getString("height", null)
        val weight = prefs.getString("weight", null)
        val conditions = prefs.getStringSet("conditions", emptySet())
        val allergies = prefs.getStringSet("allergies", emptySet())

        val bmi = try {
            val h = height?.toFloatOrNull()
            val w = weight?.toFloatOrNull()
            if (h != null && w != null && h > 0) {
                val hM = h / 100f
                String.format("%.1f", w / (hM * hM))
            } else "Unknown"
        } catch (e: Exception) {
            "Unknown"
        }

        return UserProfile(name, age, gender, bloodType, height, weight, conditions, allergies, bmi)
    }

    private fun buildSystemPrompt(profile: UserProfile): String {
        return """
            You are **Health Monitor AI**, a friendly and responsible digital wellness assistant.
            
            🔹 Your purpose:
            - Encourage healthy habits, nutrition, rest, and wellness.
            - Provide general explanations (not diagnosis).
            - Stay positive, respectful, and supportive.
            - If user mentions symptoms, recommend professional help if severe.
            
            👤 User Profile:
            - Name: ${profile.name ?: "Unknown"}
            - Age: ${profile.age ?: "N/A"}
            - Gender: ${profile.gender ?: "N/A"}
            - Blood Type: ${profile.bloodType ?: "N/A"}
            - Height: ${profile.height ?: "N/A"} cm
            - Weight: ${profile.weight ?: "N/A"} kg
            - BMI: ${profile.bmi}
            - Conditions: ${profile.conditions?.joinToString(", ") ?: "None"}
            - Allergies: ${profile.allergies?.joinToString(", ") ?: "None"}

            Start by greeting the user warmly by their name (if known).
            If they ask for advice, personalize it according to their age, BMI, and conditions.
        """.trimIndent()
    }
}
