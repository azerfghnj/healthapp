package com.example.asclepius

object DataRepository {

    private val heartRateList = mutableListOf<Float>()
    private val spo2List = mutableListOf<Float>()
    private val tempList = mutableListOf<Float>()
    private val fallList = mutableListOf<Boolean>()

    // Blood pressure lists
    private val bpSysList = mutableListOf<Float>()
    private val bpDiaList = mutableListOf<Float>()

    // Add readings
    fun addHeartRate(value: Float) {
        heartRateList.add(value)
    }

    fun addSpo2(value: Float) {
        spo2List.add(value)
    }

    fun addTemp(value: Float) {
        tempList.add(value)
    }

    fun addFall() {
        fallList.add(true)
    }

    fun addBloodPressure(systolic: Float, diastolic: Float) {
        bpSysList.add(systolic)
        bpDiaList.add(diastolic)
    }

    // Optional: expose copies of the lists
    fun getHeartRateData(): List<Float> = heartRateList.toList()
    fun getSpo2Data(): List<Float> = spo2List.toList()
    fun getTempData(): List<Float> = tempList.toList()
    fun getFallData(): List<Boolean> = fallList.toList()
    fun getBloodPressureSys(): List<Float> = bpSysList.toList()
    fun getBloodPressureDia(): List<Float> = bpDiaList.toList()
}
